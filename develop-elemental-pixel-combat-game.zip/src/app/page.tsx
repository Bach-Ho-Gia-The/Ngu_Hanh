export default function HomePage() {
  return (
    <main style={{ padding: 24, fontFamily: "sans-serif" }}>
      <a href="/game/index.html">Ngũ Hành Loạn Đấu</a>
    </main>
  );
}
