/* ======================= GOJO SATORU MODULE (Lục Nhãn · Vô Hạ Hạn) =======================
 * Inserted into the game closure. Uses engine internals: Pt, ss, Yt, ie, Fn, Gi, dt, Rt (pixelfx),
 * Y, ot, _t, lt, W0, as, a3, o3, R2, tc, $U, Y0, ze, G0, Rn, ji, Ay, l2, t0, Ou, Vt, Et, X ...
 */
var GJ = (() => {
  const HEX = {
    blue: ["#020a2a", "#06246e", "#0c52d0", "#2a8cff", "#6cc8ff", "#bff0ff", "#ffffff"],
    red: ["#2a0208", "#6e0a18", "#c4162c", "#ff3a4a", "#ff8a7a", "#ffd0c0", "#ffffff"],
    purple: ["#0a0220", "#2a0a5a", "#5a1ea8", "#9a4aff", "#d08cff", "#f0d0ff", "#ffffff"],
    void: ["#02010a", "#070320", "#0f0640", "#1c0e6e", "#2e1ca0", "#4a40d0", "#8a90ff", "#e8f4ff"],
  };
  const RGB = {};
  for (const k in HEX) RGB[k] = HEX[k].map(h => { const v = X(h); return [v & 255, (v >>> 8) & 255, (v >>> 16) & 255]; });
  const PAL = { blue: { palette: HEX.blue }, red: { palette: HEX.red }, purple: { palette: HEX.purple } };
  const B4 = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5].map(v => (v + .5) / 16);
  const clamp = (v, a = 0, b = 1) => v < a ? a : v > b ? b : v;
  const ease = k => 1 - Math.pow(1 - clamp(k), 3);
  const SX = x => Math.round(x - lt.camX), SY = (y, z = 0) => Math.round(y - lt.camY - z);

  /* ---------- Element, look, base pose ---------- */
  Pt.gojo = {
    id: "gojo", name: "Gojo", han: "眼", title: "Lục Nhãn · Vô Hạ Hạn", outer: true,
    ui: "#7fd4ff", uiDeep: "#2a52c8", ramp: HEX.blue,
    sparks: ["#ffffff", "#bff0ff", "#6cc8ff", "#2a52c8"],
    trail: ["#06246e", "#0c52d0", "#2a8cff", "#6cc8ff", "#bff0ff", "#ffffff", "#ffffff"],
    status: null,
    passive: "Vô Hạ Hạn: chặn đòn đầu tiên mỗi 8 giây. Khí hồi nhanh +70%. Giữ nút đánh để dồn lực rồi đẩy bật kẻ địch.",
    blurb: "Kẻ mạnh nhất. Xanh hút, Đỏ đẩy, Tím xóa sổ. Lướt, bay lơ lửng và triển khai Lĩnh Vực."
  };
  ss.gojo = [];
  Fn.gojo = { ...dt, fx: 3, fy: -15, bx: -1, by: -16, crouch: 2, lean: -1, ffx: 7, fbx: -7 };
  const GP = o => ({ ...Fn.gojo, ...o });
  const GLOOK = {
    id: "gojo", name: "Gojo Satoru", gear: "gojo",
    skin: vo({
      top: "#14162e", sleeve: "#14162e", sash: "#2a3a8c", bottom: "#101224", boots: "#0b0c18",
      skin: "#f4d6c0", fore: "#f4d6c0", hand: "#f4d6c0", hair: "#f2f6ff", hat: "#bff4ff", extra: "#0a0a12", ink: "#0b0b1c", mark: "#9fe4ff"
    })
  };

  /* ---------- custom pixel FX layer (drawn into the software framebuffer) ---------- */
  const fxs = [];
  const S = { t: 0, dt: 0, inv: 0, dom: null, stars: null };
  const addFx = o => { o.age = 0; fxs.push(o); if (fxs.length > 36) fxs.shift(); return o; };
  const pxBlend = (f, x, y, c, a) => {
    if (x < 0 || y < 0 || x >= f.w || y >= f.h) return;
    const i = y * f.w + x, p = f.color[i], r = p & 255, g = (p >>> 8) & 255, b = (p >>> 16) & 255;
    f.color[i] = 0xFF000000 | (((b + (c[2] - b) * a) | 0) << 16) | (((g + (c[1] - g) * a) | 0) << 8) | ((r + (c[0] - r) * a) | 0);
  };
  const pxSet = (f, x, y, c) => { if (x >= 0 && y >= 0 && x < f.w && y < f.h) f.color[y * f.w + x] = 0xFF000000 | (c[2] << 16) | (c[1] << 8) | c[0]; };
  const dith = (x, y) => B4[(x & 3) + ((y & 3) << 2)];
  const hash = (a, b) => { let h = Math.imul(a | 0, 374761393) ^ Math.imul(b | 0, 668265263); h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; };

  function dLine(f, x0, y0, x1, y1, c, th = 1) {
    let dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1, e = dx + dy, n = 0;
    while (n++ < 900) {
      for (let a = 0; a < th; a++) for (let b = 0; b < th; b++) pxSet(f, x0 + a, y0 + b, c);
      if (x0 === x1 && y0 === y1) break;
      const e2 = 2 * e;
      if (e2 >= dy) { e += dy; x0 += sx; }
      if (e2 <= dx) { e += dx; y0 += sy; }
    }
  }

  function drawOrb(f, o) {
    const k = o.age / o.life, r = o.r(k, o) * (o.scale ?? 1);
    if (r < 1) return;
    const P = RGB[o.pal], cx = SX(o.x), cy = SY(o.y, o.z), R = Math.ceil(r * 1.7);
    if (cx < -R || cy < -R || cx > f.w + R || cy > f.h + R) return;
    const fade = o.fade ? 1 - clamp((k - o.fade) / (1 - o.fade)) : 1;
    for (let y = cy - R; y <= cy + R; y++) for (let x = cx - R; x <= cx + R; x++) {
      const dx = x - cx, dy = y - cy, d = Math.hypot(dx, dy) / r;
      if (d > 1.7) continue;
      if (d <= 1) {
        const sw = Math.sin(Math.atan2(dy, dx) * 3 + d * 8 - S.t * (o.spin ?? 9));
        let lit = (1 - d) * .78 + (sw * .5 + .5) * .3 * (1 - d * .4) - (dx + dy) / (r * 9);
        lit += o.heat ?? 0;
        let idx = Math.floor(clamp(lit * 6.99 + (dith(x, y) - .5) * .6, 0, 6.99));
        if (d > .9) idx = Math.min(idx, 1 + ((x + y) & 1));
        pxBlend(f, x, y, P[idx], fade);
      } else {
        const pr = (1.7 - d) / .7 * .55 * fade * (1 - k * .3);
        if (dith(x, y) < pr) pxBlend(f, x, y, P[d < 1.25 ? 4 : d < 1.5 ? 3 : 2], .8);
      }
    }
  }

  function drawRing(f, o) {
    const k = o.age / o.life, rx = o.r0 + (o.r1 - o.r0) * ease(k), th = Math.max(1, o.th * (1 - k * .6)), fl = o.flat ?? .42;
    const P = RGB[o.pal], cx = SX(o.x), cy = SY(o.y, o.z), a = 1 - k;
    const RX = Math.ceil(rx + th + 1), RY = Math.ceil(rx * fl + th + 1);
    for (let y = cy - RY; y <= cy + RY; y++) for (let x = cx - RX; x <= cx + RX; x++) {
      const e = Math.hypot((x - cx) / rx, (y - cy) / (rx * fl)), dd = Math.abs(e - 1) * rx * (1 - fl * .25);
      if (dd > th) continue;
      if (dith(x, y) > a * 1.15) continue;
      pxSet(f, x, y, P[dd < th * .35 ? 6 : dd < th * .7 ? 5 : 3]);
    }
  }

  function drawBeam(f, o) {
    const k = o.age / o.life, P = RGB[o.pal];
    const ox = o.x, oy = o.y;
    const x0 = SX(ox), y0 = SY(oy, o.z), ux = Math.cos(o.th), uy = Math.sin(o.th), L = o.len;
    const grow = ease(k * 7), env = (k < .12 ? k / .12 : k > .75 ? 1 - (k - .75) / .25 : 1);
    const w = o.w * env * (1 + .08 * Math.sin(S.t * 50));
    if (w < .5) return;
    const x1 = x0 + ux * L * grow, y1 = y0 + uy * L * grow;
    const minX = Math.max(0, Math.floor(Math.min(x0, x1) - w * 2)), maxX = Math.min(f.w - 1, Math.ceil(Math.max(x0, x1) + w * 2));
    const minY = Math.max(0, Math.floor(Math.min(y0, y1) - w * 2)), maxY = Math.min(f.h - 1, Math.ceil(Math.max(y0, y1) + w * 2));
    for (let y = minY; y <= maxY; y++) for (let x = minX; x <= maxX; x++) {
      const px = x - x0, py = y - y0, t = px * ux + py * uy;
      if (t < -w || t > L * grow + w * .6) continue;
      let d = Math.abs(-px * uy + py * ux);
      d += (hash(x >> 1, (y >> 1) + (S.t * 30 | 0)) - .5) * w * .35;
      const tw = w * (t < w ? .6 + .4 * Math.max(0, t) / w : 1) * (t > L * grow - w ? clamp((L * grow - t) / w + .3) : 1);
      const rel = d / Math.max(1, tw);
      if (rel > 1.9) continue;
      const c = rel < .32 ? 6 : rel < .6 ? 5 : rel < .9 ? 4 : rel < 1.15 ? 3 : rel < 1.5 ? 2 : 1;
      if (c <= 2 && dith(x, y) > .5) continue;
      pxSet(f, x, y, P[c]);
    }
    for (let i = 0; i < 6; i++) {
      const t = hash(i, S.t * 20 | 0) * L * grow, off = (hash(i + 9, S.t * 20 | 0) - .5) * w * 3;
      pxSet(f, Math.round(x0 + ux * t - uy * off), Math.round(y0 + uy * t + ux * off), P[6]);
    }
  }

  function drawStreaks(f, o) {
    const k = o.age / o.life, P = RGB[o.pal], cx = SX(o.x), cy = SY(o.y, o.z), n = o.n ?? 28;
    for (let i = 0; i < n; i++) {
      const a = hash(i, o.seed) * 6.2832, r0 = (o.in ?? 20) + hash(i + 50, o.seed) * 30 + k * (o.speed ?? 160) * (.6 + hash(i + 7, o.seed));
      const len = (6 + hash(i + 3, o.seed) * 26) * (1 - k);
      if (len < 1) continue;
      dLine(f, Math.round(cx + Math.cos(a) * r0), Math.round(cy + Math.sin(a) * r0 * .8), Math.round(cx + Math.cos(a) * (r0 + len)), Math.round(cy + Math.sin(a) * (r0 + len) * .8), P[hash(i, 2) > .5 ? 6 : 4]);
    }
  }

  function drawCracks(f, o) {
    const k = o.age / o.life, P = RGB[o.pal], reveal = ease(k * 4), fade = k > .55 ? 1 - (k - .55) / .45 : 1;
    if (!o.segs) {
      o.segs = [];
      const branch = (x, y, a, len, depth) => {
        let px = x, py = y;
        for (let s = 0; s < len; s++) {
          a += (hash(px | 0, py | 0) - .5) * .9;
          const nx = px + Math.cos(a) * 7, ny = py + Math.sin(a) * 7;
          o.segs.push([px, py, nx, ny, s / len]);
          px = nx; py = ny;
          if (depth < 2 && hash(s, px | 0) > .72) branch(px, py, a + (hash(s, 5) > .5 ? .9 : -.9), Math.max(2, len - s - 2), depth + 1);
        }
      };
      for (let i = 0; i < (o.n ?? 9); i++) branch(0, 0, i / (o.n ?? 9) * 6.2832 + hash(i, 1), 8 + (hash(i, 4) * 8 | 0), 0);
    }
    const cx = SX(o.x), cy = SY(o.y, o.z), sc = o.scale ?? 1;
    for (const [x0, y0, x1, y1, d] of o.segs) {
      if (d > reveal) continue;
      if (fade < 1 && hash(x0 | 0, y1 | 0) > fade) continue;
      const ax = Math.round(cx + x0 * sc), ay = Math.round(cy + y0 * sc * .8), bx = Math.round(cx + x1 * sc), by = Math.round(cy + y1 * sc * .8);
      dLine(f, ax + 1, ay + 1, bx + 1, by + 1, P[0], 1);
      dLine(f, ax, ay, bx, by, P[6], 1);
    }
  }

  function drawDome(f, o) {
    const h = o.follow;
    if (!h || h.dead || h.gone) { o.age = o.life; return; }
    const k = o.age / o.life, P = RGB.blue, cx = SX(h.x), cy = SY(h.y, (h.z ?? 0) + 18), R = 34 + Math.sin(S.t * 6) * 1.2, hit = clamp(1 - (S.t - (h.gjBlockT ?? -9)) * 3);
    if (k > .86 && Math.floor(S.t * 14) % 2) return;
    for (let y = Math.floor(cy - R - 2); y <= cy + R + 2; y++) for (let x = Math.floor(cx - R - 2); x <= cx + R + 2; x++) {
      const dx = x - cx, dy = (y - cy) * 1.02, d = Math.hypot(dx, dy);
      if (d > R + 1.5 || d < R - 2.5 - hit * 3) continue;
      const band = Math.sin(Math.atan2(dy, dx) * 5 + S.t * 3) * .5 + .5;
      if (dith(x, y) > .3 + band * .35 + hit * .5) continue;
      pxBlend(f, x, y, P[d > R - 1 ? (band > .6 ? 6 : 5) : 3], .75);
    }
  }
  const fxDraw = { orb: drawOrb, ring: drawRing, beam: drawBeam, streak: drawStreaks, crack: drawCracks, dome: drawDome };

  /* ---------- Domain: Unlimited Void ---------- */
  function domainBg(f) {
    const d = S.dom;
    if (!d) return;
    const W = f.w, H = f.h, t = d.t, maxR = Math.hypot(W, H) * 1.05;
    let R = maxR * ease(t / .85);
    if (t > d.dur - .75) R = maxR * (1 - ease((t - (d.dur - .75)) / .75));
    const cx = clamp(SX(d.x), 0, W), cy = clamp(SY(d.y, 14), 0, H);
    if (R < 2) return;
    const P = RGB.void, col = f.color, R2_ = R * R;
    for (let by = 0; by < H; by += 3) for (let bx = 0; bx < W; bx += 3) {
      const mx = bx + 1 - cx, my = by + 1 - cy;
      if (mx * mx + my * my > (R + 5) * (R + 5)) continue;
      const u = mx / H * 2, v = my / H * 2, r = Math.hypot(u, v), th = Math.atan2(v, u);
      let w = .5 + .26 * Math.sin(th * 3 + Math.log(r + .08) * 5 - t * 1.7) + .15 * Math.sin(th * 5 - r * 9 + t * 2.4) - r * .42;
      w += (hash(bx / 3 | 0, by / 3 | 0) - .5) * .1;
      const idx = Math.floor(clamp(w * 7.2 + (dith(bx / 3 | 0, by / 3 | 0) - .5) * .9, 0, 7.99));
      const c = P[idx], pk = 0xFF000000 | (c[2] << 16) | (c[1] << 8) | c[0];
      for (let y = by; y < by + 3 && y < H; y++) for (let x = bx; x < bx + 3 && x < W; x++) {
        const dx = x - cx, dy = y - cy, dd = dx * dx + dy * dy;
        if (dd <= R2_) col[y * W + x] = pk;
        else if (dd < (R + 4) * (R + 4)) col[y * W + x] = 0xFFFFFFFF;
      }
    }
    if (!S.stars) S.stars = Array.from({ length: 170 }, (_, i) => ({ x: hash(i, 1) * 2 - 1, y: hash(i, 2) * 2 - 1, z: hash(i, 3) * .95 + .05, v: .25 + hash(i, 4) * .55 }));
    for (const s of S.stars) {
      const pz = s.z; s.z -= S.dt * s.v * .55;
      if (s.z < .04) { s.z = 1; s.x = Math.random() * 2 - 1; s.y = Math.random() * 2 - 1; continue; }
      const sx = Math.round(cx + s.x / s.z * H * .42), sy = Math.round(cy + s.y / s.z * H * .42);
      const px = Math.round(cx + s.x / pz * H * .42), py = Math.round(cy + s.y / pz * H * .42);
      if (sx < 0 || sy < 0 || sx >= W || sy >= H || (sx - cx) * (sx - cx) + (sy - cy) * (sy - cy) > R2_) continue;
      const bright = s.z < .3 ? [255, 255, 255] : s.z < .6 ? [190, 220, 255] : [110, 140, 230];
      if (s.z < .45) dLine(f, px, py, sx, sy, bright, 1);
      pxSet(f, sx, sy, [255, 255, 255]);
      if (s.z < .22) { pxSet(f, sx + 1, sy, bright); pxSet(f, sx, sy + 1, bright); }
    }
  }

  function post(f) {
    for (let i = fxs.length - 1; i >= 0; i--) if (fxs[i].age >= fxs[i].life) fxs.splice(i, 1);
    for (const o of fxs) { const fn = fxDraw[o.kind]; if (fn) fn(f, o); }
    const d = S.dom;
    if (d) {
      const W = f.w, H = f.h, col = f.color, pulse = .5 + .5 * Math.sin(d.t * 5);
      for (let y = 0; y < H; y += 2) {
        const vy = Math.abs(y / H - .5) * 2;
        if (vy < .72) continue;
        for (let x = (y >> 1) & 1; x < W; x += 2) { const i = y * W + x, p = col[i]; col[i] = 0xFF000000 | ((((p >>> 16) & 255) * .55) << 16) | ((((p >>> 8) & 255) * .55) << 8) | ((p & 255) * .55); }
      }
      if (d.t < .22 || d.t > d.dur - .2) S.inv = Math.max(S.inv, .05);
      if (pulse > .985) { const gy = (hash(d.t * 40 | 0, 3) * H) | 0; for (let x = 0; x < W; x++) { const i = gy * W + x; col[i] = col[i] ^ 0x00FFFFFF; } }
    }
    if (S.inv > 0) { const col = f.color; for (let i = 0; i < col.length; i++) col[i] ^= 0x00FFFFFF; }
  }

  /* ---------- public fx helpers ---------- */
  const orb = (x, y, z, pal, life, r, extra) => addFx({ kind: "orb", x, y, z, pal, life, r, ...extra });
  const ring = (x, y, pal, r0, r1, life, th = 3, z = 0) => addFx({ kind: "ring", x, y, z, pal, r0, r1, life, th });
  const beam = (o) => addFx({ kind: "beam", pal: "purple", z: 26, w: 18, ...o });
  const streak = (x, y, z, pal, life, extra) => addFx({ kind: "streak", x, y, z, pal, life, seed: Math.random() * 999 | 0, ...extra });
  const crack = (x, y, z, pal, life, extra) => addFx({ kind: "crack", x, y, z, pal, life, ...extra });
  const near = (h, r = 260) => !!Y.me && Math.abs(Y.me.x - h.x) < r;

  /* ---------- voice + subtitles ---------- */
  const LINES = {
    ao: { c: "#4aa8ff", ja: "術式順転『蒼』", rom: "Jutsushiki Juntén — Ao", vi: "Thuật thức thuận chuyển — Xanh" },
    aka: { c: "#ff4a5a", ja: "術式反転『赫』", rom: "Jutsushiki Hanten — Aka", vi: "Thuật thức phản chuyển — Đỏ" },
    murasaki: { c: "#b46cff", ja: "虚式『茈』", rom: "Kyoshiki — Murasaki", vi: "Hư thức — Tím" },
    domain: { c: "#9fb4ff", ja: "領域展開『無量空処』", rom: "Ryōiki Tenkai — Muryōkūsho", vi: "Lĩnh vực triển khai — Vô Lượng Không Xứ" },
    mugen: { c: "#7fd4ff", ja: "無下限呪術", rom: "Mukagen Jujutsu", vi: "Vô Hạ Hạn chú thuật" },
    rct: { c: "#8fffb4", ja: "反転術式", rom: "Hanten Jutsushiki", vi: "Phản chuyển thuật thức — hồi phục" },
    blink: { c: "#cfe6ff", ja: "遅いよ", rom: "Osoi yo", vi: "Chậm quá đấy~" },
    hold: { c: "#ff9a7a", ja: "ふっ飛べ", rom: "Futtobe", vi: "Bay đi!" },
    honored: { c: "#bff0ff", ja: "天上天下 唯我独尊", rom: "Tenjō tenge, yuiga dokuson", vi: "Trên trời dưới đất, duy ngã độc tôn." },
  };
  let subEl = null, subTimer = 0, voices = [];
  const loadVoices = () => { try { voices = speechSynthesis.getVoices(); } catch (e) { voices = []; } };
  try { loadVoices(); speechSynthesis.addEventListener && speechSynthesis.addEventListener("voiceschanged", loadVoices); } catch (e) { }
  function ensureSub() {
    if (subEl) return subEl;
    subEl = document.createElement("div"); subEl.id = "gj-sub"; subEl.setAttribute("aria-live", "polite");
    subEl.innerHTML = '<div class="gj-k"></div><div class="gj-r"></div><div class="gj-v"></div>';
    (document.getElementById("ui") || document.body).appendChild(subEl);
    return subEl;
  }
  function say(key, opts = {}) {
    const L = LINES[key]; if (!L) return;
    const el = ensureSub(); el.style.setProperty("--c", L.c);
    el.querySelector(".gj-k").textContent = L.ja; el.querySelector(".gj-r").textContent = L.rom; el.querySelector(".gj-v").textContent = L.vi;
    el.classList.remove("on"); void el.offsetWidth; el.classList.add("on");
    clearTimeout(subTimer); subTimer = setTimeout(() => el.classList.remove("on"), opts.ms ?? 2600);
    const vol = Y.save?.opts?.sfx ?? .8;
    if (vol <= 0) return;
    let spoke = false;
    try {
      const ja = voices.find(v => /^ja/i.test(v.lang)) || speechSynthesis.getVoices().find(v => /^ja/i.test(v.lang));
      if (ja) {
        speechSynthesis.cancel();
        const u = new SpeechSynthesisUtterance(L.ja.replace(/[『』]/g, " "));
        u.voice = ja; u.lang = ja.lang; u.pitch = .62; u.rate = key === "domain" ? .78 : key === "honored" ? .72 : .92; u.volume = Math.min(1, vol + .15);
        speechSynthesis.speak(u); spoke = true;
      }
    } catch (e) { }
    if (!spoke) ot("sfx", "gojoVoice", null, key === "domain" ? 1.4 : 1);
  }

  /* ---------- custom sound effects (procedural synth, same engine as the game's) ---------- */
  const SFX = {
    gojoPunch: (a, t, e) => { Et(a, 190, .12, .34 * t, { type: "sine", to: 55, pan: e }); Vt(a, 2400, .07, .3 * t, { type: "highpass", pan: e }); Et(a + .01, 1320, .09, .12 * t, { type: "triangle", to: 880, pan: e }); },
    gojoBlue: (a, t, e) => { for (let i = 0; i < 6; i++) Et(a + i * .09, 220 + i * 90, .5, .1 * t, { type: "sine", to: 900 + i * 160, pan: e }); Vt(a, 600, .9, .16 * t, { type: "bandpass", to: 3200, q: 3, pan: e }); },
    gojoBlueEnd: (a, t, e) => { Et(a, 520, .5, .38 * t, { type: "sine", to: 30, pan: e }); Vt(a, 2800, .45, .4 * t, { type: "lowpass", to: 120, q: 1, pan: e }); Et(a, 90, .7, .3 * t, { type: "square", to: 28, pan: e }); },
    gojoRed: (a, t, e) => { Et(a, 140, .35, .32 * t, { type: "sawtooth", to: 620, pan: e }); Vt(a, 1800, .3, .24 * t, { type: "bandpass", to: 700, q: 2, pan: e }); Et(a + .05, 1400, .2, .1 * t, { type: "square", to: 400, pan: e }); },
    gojoRedEnd: (a, t, e) => { Et(a, 120, .6, .6 * t, { type: "sine", to: 28, pan: e }); Vt(a, 3200, .5, .55 * t, { type: "lowpass", to: 90, q: .7, pan: e }); Vt(a + .02, 6000, .12, .3 * t, { type: "highpass", pan: e }); Et(a, 70, .8, .4 * t, { type: "square", to: 24, pan: e }); },
    gojoPurple: (a, t, e) => { for (let i = 0; i < 5; i++) { Et(a + i * .07, 110 * (1 + i * .5), .9, .12 * t, { type: "sawtooth", to: 880 * (1 + i * .25), pan: e }); } Vt(a, 400, 1, .2 * t, { type: "bandpass", to: 4200, q: 4, pan: e }); Et(a + .45, 2000, .6, .12 * t, { type: "triangle", to: 60, pan: e }); },
    gojoBeam: (a, t, e) => { Et(a, 55, 1.3, .6 * t, { type: "sawtooth", to: 38, pan: e }); Et(a, 82, 1.2, .35 * t, { type: "square", to: 41, pan: e }); Vt(a, 5000, 1.2, .5 * t, { type: "bandpass", to: 600, q: .9, pan: e }); Et(a, 880, 1.0, .12 * t, { type: "sawtooth", to: 220, pan: e }); },
    gojoDomain: (a, t, e) => { Et(a, 55, 2.2, .45 * t, { type: "sine", to: 110, pan: e }); for (let i = 0; i < 7; i++) Et(a + .1 + i * .13, 330 * Math.pow(1.5, i % 4), .9, .08 * t, { type: "triangle", to: 330 * Math.pow(1.5, i % 4) * .5, pan: e }); Vt(a, 300, 1.8, .22 * t, { type: "bandpass", to: 5000, q: 2, pan: e }); Et(a + .75, 1760, 1.2, .1 * t, { type: "sine", to: 1740, pan: e }); },
    gojoBlink: (a, t, e) => { Vt(a, 5200, .16, .32 * t, { type: "bandpass", to: 800, q: 2, pan: e }); Et(a, 1500, .14, .12 * t, { type: "sine", to: 240, pan: e }); Et(a + .1, 300, .12, .15 * t, { type: "sine", to: 900, pan: e }); },
    gojoMugen: (a, t, e) => { for (let i = 0; i < 5; i++) Et(a + i * .06, 660 * Math.pow(1.26, i), .5, .1 * t, { type: "sine", to: 660 * Math.pow(1.26, i) * 1.01, pan: e }); Vt(a, 3000, .6, .1 * t, { type: "bandpass", to: 1200, q: 6, pan: e }); },
    gojoBlock: (a, t, e) => { Et(a, 1400, .25, .22 * t, { type: "sine", to: 300, pan: e }); Vt(a, 4000, .15, .2 * t, { type: "bandpass", to: 1500, q: 4, pan: e }); Et(a + .03, 2100, .3, .1 * t, { type: "triangle", to: 2000, pan: e }); },
    gojoHeal: (a, t, e) => { for (let i = 0; i < 4; i++) Et(a + i * .08, 523 * Math.pow(1.25, i), .45, .14 * t, { type: "sine", pan: e }); },
    gojoCharge: (a, t, e) => { Et(a, 160, .3, .14 * t, { type: "sawtooth", to: 700, pan: e }); Vt(a, 900, .3, .1 * t, { type: "bandpass", to: 3000, q: 3, pan: e }); },
    gojoRelease: (a, t, e) => { Et(a, 200, .35, .5 * t, { type: "sine", to: 36, pan: e }); Vt(a, 3600, .3, .5 * t, { type: "lowpass", to: 160, pan: e }); Vt(a, 7000, .1, .25 * t, { type: "highpass", pan: e }); },
    gojoVoice: (a, t, e) => { [0, 3, 5, 3, 7, 5, 2, 0].forEach((s, i) => Et(a + i * .075, 130 * Math.pow(2, s / 12), .08, .14 * t, { type: "square", to: 130 * Math.pow(2, s / 12) * .96, pan: e })); },
  };;

  /* ---------- helpers for skill defs ---------- */
  const pulse = (m, pal = "blue", r1 = 34) => { const p = m.ahead(m.def.reach ?? 30); ring(p.x, p.y, pal, 4, r1, .34, 3, 18); };
  const gh = (h, n = 6) => { for (let i = 0; i < n; i++) h.ghosts.length < 8 && h.ghosts.push({ r: ls(h.pose), x: h.x - h.face * i * 5, y: h.y, z: h.z, flip: h.face < 0, age: i * .015, rot: h.rot }); };

  /* ---------- combo (Lục Nhãn Quyền) ---------- */
  ie("gjA1", {
    track: [[-.14, GP({ crouch: 4, lean: -2, fx: 2, fy: -17, bx: -3, by: -17 })], [-.05, GP({ crouch: 5, lean: 3, fx: 9, fy: -22, bx: -4, by: -17, x: -1 })],
      [0, GP({ x: 4, crouch: 4, lean: 7, fx: 25, fy: -27, bx: -4, by: -17, ffx: 13, fbx: -9, toeB: !0, ghost: 1 }), "snap"], [.12, GP({ x: 4, lean: 6, fx: 22, fy: -27, bx: -4, by: -17 })], [.3, GP({})]],
    lead: .1, end: .3, cancel: .14, step: 12, reach: 32,
    hits: [{ t: 0, range: 38, depth: 15, dmg: .8, push: 34, stun: .28, stop: .05, shake: 1.6, fx: "impacts/hit-spark" }],
    on: [{ t: 0, fn: (a, m) => pulse(m, "blue", 30) }], sfx: [{ t: -.02, id: "gojoPunch" }]
  });
  ie("gjA2", {
    track: [[-.15, GP({ crouch: 5, lean: -4, fx: -2, fy: -20, bx: 8, by: -22, twist: -.4 })],
      [-.04, GP({ crouch: 6, lean: -7, fx: -7, fy: -23, bx: 12, by: -25, twist: -.6, ffx: 9 })],
      [0, GP({ x: 5, crouch: 5, lean: 8, fx: -3, fy: -23, bx: 26, by: -26, armsFront: !0, ffx: 13, fbx: -10, twist: .5, ghost: 1 }), "snap"],
      [.14, GP({ x: 5, lean: 7, fx: -3, fy: -23, bx: 24, by: -26 })], [.32, GP({ x: 3 })]],
    lead: .1, end: .32, cancel: .16, step: 12, reach: 36,
    fx: [{ id: "melee/sword-slash", t: -.02, ox: 12, oz: 24, rate: 1.7, tint: "trail", sync: !1 }],
    hits: [{ t: 0, range: 44, depth: 17, dmg: .95, push: 52, stun: .3, stop: .06, shake: 2, fx: "impacts/hit-spark" }],
    on: [{ t: 0, fn: (a, m) => pulse(m, "blue", 34) }], sfx: [{ t: -.02, id: "swing2" }, { t: 0, id: "gojoPunch" }]
  });
  ie("gjA3", {
    track: [[-.16, GP({ crouch: 7, lean: 3, fx: 4, fy: -17, bx: -4, by: -17, ffx: 5, ffy: 0, fbx: -6 })],
      [-.04, GP({ crouch: 11, lean: 8, fx: 7, fy: -15, bx: -5, by: -15, ffx: 8, ffy: 0, fbx: -9, twist: -.2 })],
      [0, GP({ x: 5, crouch: 10, lean: -3, fx: 3, fy: -15, bx: -4, by: -16, ffx: 24, ffy: -3, fbx: -8, toeB: !0, ghost: 1 }), "snap"],
      [.15, GP({ x: 5, crouch: 9, lean: -2, ffx: 22, ffy: -3, fx: 3, fy: -15, bx: -4, by: -16 })], [.34, GP({ x: 3 })]],
    lead: .11, end: .34, cancel: .18, step: 12, reach: 38,
    fx: [{ id: "melee/spin-slash", t: -.02, ox: 4, oz: 6, rate: 1.9, tint: "trail", sync: !1 }],
    hits: [{ t: 0, range: 46, depth: 20, dmg: 1, push: 70, stun: .38, stop: .06, shake: 2.4, down: !0, fx: "impacts/hit-spark" }],
    on: [{ t: 0, fn: (a, m) => pulse(m, "blue", 38) }], sfx: [{ t: -.03, id: "swing3" }, { t: 0, id: "gojoPunch" }]
  });
  ie("gjA4", {
    track: [[-.18, GP({ crouch: 6, lean: -4, fx: 4, fy: -19, bx: -5, by: -18, ffx: 4, ffy: -3, fbx: -5 })],
      [-.04, GP({ crouch: 4, lean: -10, fx: 5, fy: -20, bx: -6, by: -20, ffx: 6, ffy: -8, fbx: -4, toeB: !0 })],
      [0, GP({ x: 5, crouch: 1, lean: -11, fx: -4, fy: -22, bx: 8, by: -30, ffx: 20, ffy: -24, fbx: -3, toeB: !0, ghost: 1 }), "snap"],
      [.16, GP({ x: 5, crouch: 1, lean: -10, fx: -4, fy: -22, bx: 8, by: -30, ffx: 19, ffy: -23 })], [.38, GP({ x: 4 })]],
    lead: .12, end: .38, cancel: .22, step: 14, reach: 40,
    fx: [{ id: "melee/uppercut", t: -.02, ox: 8, oz: 18, rate: 1.6, tint: "trail", sync: !1 }],
    hits: [{ t: 0, range: 46, depth: 20, dmg: 1.2, push: 40, lift: 240, stun: .5, stop: .08, shake: 3, heavy: !0, fx: "impacts/crit-hit" }],
    on: [{ t: 0, fn: (a, m) => { pulse(m, "blue", 44); const p = m.ahead(26); streak(p.x, p.y, 28, "blue", .22, { n: 16, speed: 90 }); } }], sfx: [{ t: -.03, id: "swing3" }, { t: 0, id: "gojoPunch" }]
  });
  ie("gjA5", {
    track: [[-.22, GP({ crouch: 6, lean: -5, fx: 3, fy: -20, bx: -2, by: -19, ffx: 5 })],
      [-.08, GP({ crouch: 7, lean: -7, fx: 4, fy: -22, bx: 3, by: -22, armsFront: !0, ffx: 9, fbx: -9, ghost: 1 })],
      [0, GP({ x: 6, crouch: 5, lean: 11, fx: 27, fy: -27, bx: 24, by: -25, armsFront: !0, ffx: 15, fbx: -11, toeB: !0, toeF: !0, ghost: 1 }), "snap"],
      [.18, GP({ x: 6, crouch: 5, lean: 10, fx: 25, fy: -27, bx: 22, by: -25, armsFront: !0 })], [.46, GP({ x: 4 })]],
    lead: .16, end: .46, cancel: .3, step: 14, reach: 44,
    fx: [{ id: "impacts/ground-slam", t: .02, ox: 36, rate: 1.6, opts: PAL.blue, sync: !1, ground: !0 }],
    hits: [{ t: 0, range: 52, depth: 26, dmg: 1.7, push: 150, lift: 90, stun: .55, stop: .1, shake: 5, heavy: !0, fx: "impacts/crit-hit" }],
    on: [{ t: 0, fn: (a, m) => {
      const p = m.ahead(30);
      Y0(a, { ...d2(a, m), ...Us(m, 330), life: .5, r: 12, el: "gojo", fx: "projectiles/energy-disc", fxOpts: PAL.blue, pierce: 4, hit: { dmg: 1.1 * m.power, push: 240, stun: .4, stop: .04, shake: 2.5, fx: null } });
      ring(p.x, p.y, "blue", 6, 58, .5, 4, 20); ring(p.x, p.y, "blue", 2, 36, .35, 3, 20);
      streak(p.x, p.y, 26, "blue", .3, { n: 20, speed: 130 });
      R2(.05); $U(.6);
    } }], sfx: [{ t: -.02, id: "gojoRelease" }, { t: 0, id: "boom" }]
  });
  Gi.gojo = { chain: ["gjA1", "gjA2", "gjA3", "gjA4", "gjA5"], dash: "gjDash", name: "Lục Nhãn Quyền", blurb: "Năm đòn: chưởng, tảo, cước, hất tung và Song Chưởng đẩy sóng. Giữ nút đánh để dồn lực." };

  ie("gjDash", {
    track: [[-.1, GP({ crouch: 7, lean: 6, fx: 9, fy: -20, bx: -4, by: -19, ffx: 9, fbx: -9 })],
      [0, GP({ x: 6, crouch: 6, lean: 10, fx: 24, fy: -24, bx: -3, by: -18, ffx: 14, fbx: -11, toeB: !0, ghost: 1 }), "snap"],
      [.14, GP({ x: 6, lean: 9, fx: 22, fy: -24, bx: -3, by: -18 })], [.34, GP({ x: 3 })]],
    lead: .06, end: .34, cancel: .18, step: 26, reach: 40,
    fx: [{ id: "moves/dash-strike", t: -.04, rate: 1.7, tint: "trail", sync: !1 }],
    hits: [{ t: 0, range: 50, depth: 20, dmg: 1.4, push: 110, lift: 120, stun: .45, stop: .08, shake: 3, heavy: !0, fx: "impacts/crit-hit" }],
    on: [{ t: 0, fn: (a, m) => { pulse(m, "blue", 42); gh(a, 5); } }], sfx: [{ t: -.03, id: "gojoBlink" }, { t: 0, id: "gojoPunch" }]
  });

  /* ---------- hold-attack: charge, then repulse ---------- */
  const holdDef = (lv) => ({
    track: [[-.12, GP({ crouch: 5, lean: -4, fx: 14, fy: -27, bx: 4, by: -21, ffx: 9 })],
      [0, GP({ x: lv ? 7 : 4, crouch: 5, lean: 12, fx: 28, fy: -27, bx: 25, by: -26, armsFront: !0, ffx: 15, fbx: -11, toeB: !0, toeF: !0, ghost: 1 }), "snap"],
      [.2, GP({ x: lv ? 7 : 4, lean: 11, fx: 26, fy: -27, bx: 23, by: -26, armsFront: !0 })], [lv ? .6 : .48, GP({ x: 3 })]],
    lead: .05, end: lv ? .6 : .48, cancel: lv ? .4 : .32, reach: 60, rootK: .6,
    hits: [{ t: 0, range: lv ? 190 : 120, depth: lv ? 62 : 44, dmg: lv ? 3.4 : 1.9, push: lv ? 420 : 270, lift: lv ? 170 : 110, stun: lv ? .9 : .6, stop: lv ? .14 : .1, shake: lv ? 9 : 5, flash: lv ? .3 : .15, heavy: !0, fx: "impacts/crit-hit", sfx: "boom" }],
    on: [{ t: 0, fn: (a, m) => {
      const p = m.ahead(34), k = lv ? 1.7 : 1;
      ring(p.x, p.y, "blue", 6, 70 * k, .5, 4, 22); ring(p.x, p.y, "red", 2, 48 * k, .42, 3, 22);
      streak(p.x, p.y, 26, "blue", .34, { n: 30, speed: 220 * k });
      Y0(a, { ...d2(a, m), ...Us(m, 380 * k), life: .45 * k, r: 14 * k, el: "gojo", fx: "projectiles/energy-disc", fxOpts: PAL.red, pierce: 6, hit: { dmg: .9 * m.power, push: 320, stun: .5, stop: .03, fx: null } });
      Rt("explosions/small-explosion", { x: p.x, y: p.y, z: 24, rate: 1.7, palette: HEX.red, prio: 2 });
      if (lv) { crack(p.x + m.ux * 20, p.y, 26, "blue", .6, { n: 7, scale: 1.1 }); S.inv = Math.max(S.inv, .06); }
      $U(lv ? 1 : .6); a3(lv ? 3 : 2); a.local && o3(SX(p.x), SY(p.y, 24), lv ? 2 : 1, "#7fd4ff");
    } }], sfx: [{ t: -.02, id: "gojoRelease" }]
  });
  ie("gjH1", holdDef(0));
  ie("gjH2", holdDef(1));

  /* ---------- 7 skills ---------- */
  const aimPrep = n0(210, 100);

  Yt("gojo1", "gojo", 1, "Xanh · Thuận Chuyển", 14, 4.5, "Tạo một điểm kỳ dị xanh tại vùng ngắm: hút mọi kẻ địch vào tâm, rồi sụp đổ thành vụ nổ nén.", {
    track: [[-.2, GP({ crouch: 4, lean: -2, fx: 6, fy: -22, bx: -2, by: -16 })], [-.04, GP({ crouch: 5, lean: -4, fx: 12, fy: -35, bx: -3, by: -18, toeB: !0 })],
      [0, GP({ x: 1, crouch: 4, lean: 3, fx: 25, fy: -34, bx: -4, by: -18, ffx: 11 }), "snap"], [.4, GP({ lean: 3, fx: 23, fy: -32, bx: -4, by: -18 })], [.62, GP({})]],
    lead: .2, end: .62, cancel: .44, prep: aimPrep,
    on: [{ t: 0, fn: (a, m) => {
      const e = m.o.data, z = 26, pw = m.power;
      orb(e.x, e.y, z, "blue", 1.25, (k) => k < .78 ? 3 + 13 * ease(k / .5) : 16 * (1 - (k - .78) / .22) + 1, { spin: 12, fade: .9 });
      ring(e.x, e.y, "blue", 90, 8, 1.0, 3);
      Rt("arcane/spell-charge", { x: e.x, y: e.y, z, rate: 1.1, palette: HEX.blue, prio: 2 });
      Rt("shadow/void-orb", { x: e.x, y: e.y, z, rate: 1.3, palette: HEX.blue, prio: 2, life: 1.1 });
      G0(a, { x: e.x, y: e.y, rx: 120, ry: 52, dur: 1.05, tick: .15, first: .12, el: "gojo", pull: 210, hit: { dmg: .26 * pw, push: 0, stun: .3, stop: 0, shake: .3, fx: null, pull: 120 } });
      Rn(1.05, () => {
        ze(a, { x: e.x, y: e.y, z, fx: "explosions/implosion", rate: 1.5, opts: PAL.blue, el: "gojo", hits: [{ t: 0, rx: 84, hit: { dmg: 3.2 * pw, lift: 210, push: 70, stun: .65, heavy: !0, fx: null }, shake: 6, flash: .3, sfx: "gojoBlueEnd" }] });
        ring(e.x, e.y, "blue", 6, 100, .5, 5); streak(e.x, e.y, z, "blue", .4, { n: 26, in: 4, speed: 120 });
        near(a) && (a3(2), $U(.8));
      });
      say("ao");
    } }], sfx: [{ t: 0, id: "gojoBlue" }]
  }, { range: 210, tag: "Hút · Điểm xa", show: { fx: "shadow/void-orb", opts: PAL.blue } });

  Yt("gojo2", "gojo", 2, "Đỏ · Phản Chuyển", 18, 5, "Bắn quả cầu đỏ cực nén. Chạm vào là phát nổ, hất văng mọi thứ ra xa.", {
    track: [[-.2, GP({ crouch: 5, lean: -3, fx: 4, fy: -24, bx: -4, by: -18 })], [-.05, GP({ crouch: 5, lean: -6, fx: 14, fy: -30, bx: -5, by: -19, toeB: !0 })],
      [0, GP({ x: 2, crouch: 4, lean: 6, fx: 27, fy: -27, bx: -5, by: -19, ffx: 13, fbx: -10, ghost: 1 }), "snap"], [.3, GP({ lean: 5, fx: 25, fy: -27, bx: -5, by: -19 })], [.54, GP({})]],
    lead: .2, end: .54, cancel: .34,
    on: [{ t: -.1, fn: (a, m) => { const p = m.ahead(26); orb(p.x, p.y, 27, "red", .3, k => 2 + 8 * ease(k / .9), { spin: 14, fade: .6 }); Rt("arcane/spell-charge", { x: p.x, y: p.y, z: 27, rate: 1.8, palette: HEX.red, prio: 2 }); say("aka"); } },
      { t: 0, fn: (a, m) => {
        const pr = Y0(a, {
          ...d2(a, m), ...Us(m, 330), life: .8, r: 11, el: "gojo", fx: "projectiles/plasma-shot", fxOpts: PAL.red,
          hit: { dmg: 2.2 * m.power, push: 220, lift: 90, stun: .45, heavy: !0, shake: 4 },
          burst: { fx: "explosions/plasma-explosion", rate: 1.35, rx: 74, onFloor: !0, opts: PAL.red, hit: { dmg: 2.7 * m.power, push: 330, lift: 200, stun: .7, heavy: !0, fx: null }, shake: 8, flash: .3, sfx: "gojoRedEnd" }
        });
        pr.onStep = (p, dt) => { (p.gjT = (p.gjT ?? 0) + dt) > .035 && (p.gjT = 0, orb(p.x, p.y, p.z, "red", .2, k => 7 * (1 - k) + 1, { spin: 6 })); };
        const q = m.ahead(26); ring(q.x, q.y, "red", 4, 40, .3, 3, 26); streak(q.x, q.y, 26, "red", .25, { n: 14, speed: 100 });
        W0(2.5, .14); a3(1);
      } }],
    sfx: [{ t: -.05, id: "gojoRed" }]
  }, { range: 230, tag: "Đẩy · Tầm xa", show: { fx: "projectiles/plasma-shot", opts: PAL.red } });

  Yt("gojo3", "gojo", 3, "Thuấn Bộ", 12, 3.2, "Biến mất rồi hiện ra sau lưng kẻ địch gần nhất, tung cước xoay hất tung. Không có địch thì bước một đoạn.", {
    track: [[-.1, GP({ crouch: 5, lean: 4, fx: 6, fy: -18, bx: -3, by: -17 })], [0, GP({ x: 3, crouch: 3, lean: -8, fx: -4, fy: -22, bx: 7, by: -28, ffx: 18, ffy: -20, fbx: -3, toeB: !0, ghost: 1 }), "snap"],
      [.18, GP({ x: 3, crouch: 3, lean: -8, fx: -4, fy: -22, bx: 7, by: -28, ffx: 17, ffy: -19 })], [.42, GP({ x: 3 })]],
    lead: .08, end: .42, cancel: .28,
    prep: (a, m) => {
      const tg = l2(a, 240);
      let x, y, th;
      if (tg) { const s = Math.sign(tg.x - a.x) || a.face; x = tg.x - s * 28; y = tg.y + 1; th = Math.atan2(tg.y - y, tg.x - x); }
      else { let ex = a.intent?.mx ?? 0, ey = (a.intent?.my ?? 0) * .7; const l = Math.hypot(ex, ey); if (m?.manual || l < .3) { ex = Math.cos(En(a)); ey = Math.sin(En(a)); } else { ex /= l; ey /= l; } let d = 150; while (d > 20 && Y.world?.blocked(a.x + ex * d, a.y + ey * d)) d -= 16; x = a.x + ex * d; y = a.y + ey * d; th = Math.atan2(ey, ex); }
      let g = 0; while (g++ < 8 && Y.world?.blocked(x, y)) { x = (x + a.x) / 2; y = (y + a.y) / 2; }
      return { x: Math.round(x), y: Math.round(y), fx: Math.round(a.x), fy: Math.round(a.y), th, tg: !!tg };
    },
    on: [{ t: -.06, fn: (a, m) => {
      const e = m.o.data;
      Rt("arcane/blink-out", { x: e.fx, y: e.fy, bias: 1, rate: 1.8, palette: HEX.blue, prio: 2, who: a });
      ring(e.fx, e.fy, "blue", 4, 46, .35, 3); streak(e.fx, e.fy, 20, "blue", .3, { n: 18, speed: 150 });
      a.x = e.x; a.y = e.y; a.z = 0; a.vx = a.vy = 0; a.nb = null; a.invuln = Math.max(a.invuln, .5);
      e0(a, e.th);
      Rt("arcane/blink-in", { x: e.x, y: e.y, bias: 1, rate: 1.8, palette: HEX.blue, prio: 2, who: a });
      ring(e.x, e.y, "blue", 3, 40, .3, 3); gh(a, 7);
      near(a) && (a3(1), W0(2, .12));
      say("blink");
    } }],
    hits: [{ t: .02, kind: "circle", rx: 62, ry: 34, ox: 18, dmg: 2.4, push: 140, lift: 190, stun: .6, stop: .1, shake: 4.5, heavy: !0, fx: "impacts/crit-hit" }],
    sfx: [{ t: -.06, id: "gojoBlink" }, { t: .02, id: "gojoPunch" }]
  }, { range: 150, tag: "Lao tới", show: { fx: "arcane/blink-out", opts: PAL.blue } });

  Yt("gojo4", "gojo", 4, "Vô Hạ Hạn", 24, 15, "Khoảng cách giữa bạn và đòn đánh trở nên vô hạn trong 5 giây: không gì chạm được, kẻ địch lại gần bị đẩy bật ra.", {
    track: [[-.15, GP({ crouch: 3, lean: -2, fx: 8, fy: -22, bx: -4, by: -18 })], [0, GP({ x: 0, crouch: 3, lean: -4, fx: 22, fy: -26, bx: -7, by: -24, ffx: 9, fbx: -8 }), "snap"],
      [.3, GP({ lean: -4, fx: 21, fy: -26, bx: -7, by: -24 })], [.55, GP({})]],
    lead: .15, end: .55, cancel: .3, armorT: .6,
    on: [{ t: 0, fn: (a, m) => {
      a.addStatus("ward", { dur: 5 }); a.infT = 5; a.invuln = Math.max(a.invuln, .5);
      addFx({ kind: "dome", follow: a, life: 5, pal: "blue" });
      ring(a.x, a.y, "blue", 6, 64, .6, 4); ring(a.x, a.y, "blue", 2, 44, .45, 3);
      G0(a, { x: a.x, y: a.y, rx: 66, ry: 36, dur: 5, tick: .45, first: .25, follow: a, el: "gojo", hit: { dmg: .12, push: 150, stun: .35, stop: 0, shake: 0, fx: null } });
      say("mugen");
    } }], sfx: [{ t: 0, id: "gojoMugen" }]
  }, { range: 70, tag: "Phòng thủ", show: { fx: "holy/divine-shield", opts: PAL.blue } });

  Yt("gojo5", "gojo", 5, "Phản Chuyển Hồi Phục", 26, 16, "Dùng năng lượng nguyền rủa phản chuyển để chữa lành: hồi 45% sinh lực cho bạn và đồng đội gần, gột sạch trạng thái xấu.", {
    track: [[-.12, GP({ crouch: 3, lean: -2, fx: 4, fy: -22, bx: -2, by: -18 })], [0, GP({ crouch: 4, lean: -3, fx: 7, fy: -29, bx: 8, by: -26, armsFront: !0 }), "snap"],
      [.9, GP({ crouch: 4, lean: -3, fx: 7, fy: -29, bx: 8, by: -26, armsFront: !0 })], [1.05, GP({})]],
    lead: .12, end: 1.05, cancel: .95, armorT: 1.1,
    on: [{ t: 0, fn: (a, m) => {
      say("rct");
      Rt("holy/heal-aoe", { x: a.x, y: a.y, rate: 1, prio: 2 });
      for (let i = 0; i < 6; i++) Rn(i * .16, () => {
        if (a.dead || a.gone) return;
        for (const r of Y.players) if ((r.local || r === a) && r.alive && Dr(a, r) && Math.hypot(r.x - a.x, (r.y - a.y) * 1.6) < 150) t0(r, r.maxHp * .075);
        orb(a.x + (Math.random() - .5) * 20, a.y, 10 + Math.random() * 28, Math.random() > .5 ? "blue" : "red", .35, k => 4 * (1 - k) + 1, { spin: 5 });
      });
      M3(a, a.x, a.y, 150, 0);
      ring(a.x, a.y, "red", 4, 60, .8, 3); ring(a.x, a.y, "blue", 8, 72, .8, 2);
    } }], sfx: [{ t: 0, id: "gojoHeal" }]
  }, { range: 90, tag: "Hồi phục", show: { fx: "holy/heal", opts: {} } });

  Yt("gojo6", "gojo", 6, "Hư Thức · Tím", 40, 12, "Va chạm Xanh và Đỏ: tạo khối Tím xóa sổ mọi thứ trên đường bay, xuyên qua tất cả kẻ địch.", {
    track: [[-.34, GP({ crouch: 4, lean: -3, fx: 4, fy: -22, bx: -3, by: -18 })], [-.2, GP({ crouch: 5, lean: -5, fx: 12, fy: -36, bx: 14, by: -22, armsFront: !0, toeB: !0 })],
      [0, GP({ crouch: 5, lean: -3, fx: 22, fy: -31, bx: 18, by: -26, armsFront: !0, ghost: 1 }), "snap"],
      [.3, GP({ x: 0, crouch: 5, lean: -4, fx: 24, fy: -30, bx: 20, by: -27, armsFront: !0 })], [.34, GP({ x: -4, crouch: 6, lean: 5, fx: 29, fy: -29, bx: 26, by: -27, armsFront: !0, ghost: 1 }), "snap"],
      [1.2, GP({ x: -4, crouch: 6, lean: 5, fx: 29, fy: -29, bx: 26, by: -27, armsFront: !0 })], [1.5, GP({})]],
    lead: .34, end: 1.5, cancel: 1.28, armorT: 1.4, rootK: .5,
    hits: [{ t: .36, every: .085, until: 1.05, range: 430, depth: 36, ox: 12, dmg: 1.75, push: 170, lift: 80, stun: .55, stop: .025, shake: 3.5, heavy: !0, fx: "impacts/hit-flash" }],
    on: [
      { t: -.3, fn: (a, m) => {
        a.eyesT = 3; say("murasaki", { ms: 3200 });
        const px = a.x + m.ux * 28, py = a.y + m.uy * 28, z = 30;
        const bo = orb(a.x - m.ux * 18, a.y - m.uy * 18, z, "blue", .56, () => 11, { spin: 11 });
        const ro = orb(a.x + m.ux * 54, a.y + m.uy * 54, z, "red", .56, () => 11, { spin: -11 });
        bo.mv = [bo.x, bo.y, px, py]; ro.mv = [ro.x, ro.y, px, py];
        const upd = (o) => () => { const k = ease(clamp(o.age / .5)); o.x = o.mv[0] + (o.mv[2] - o.mv[0]) * k; o.y = o.mv[1] + (o.mv[3] - o.mv[1]) * k; };
        bo.step = upd(bo); ro.step = upd(ro);
        Rt("arcane/spell-charge", { follow: a, oz: 30, ox: 10, palette: HEX.purple, rate: 1.0, prio: 2 });
      } },
      { t: .22, fn: (a, m) => {
        const px = a.x + m.ux * 28, py = a.y + m.uy * 28;
        orb(px, py, 30, "purple", .6, k => 6 + 12 * ease(k / .5), { spin: 16, fade: .85 });
        Rt("arcane/arcane-orb", { x: px, y: py, z: 30, rate: 1.4, palette: HEX.purple, prio: 2, life: .55 });
        S.inv = Math.max(S.inv, .07); R2(.1); near(a) && (W0(5, .3), a3(3));
        ring(px, py, "purple", 4, 70, .45, 4, 30); ring(px, py, "blue", 4, 50, .35, 3, 30);
        a.local && o3(SX(px), SY(py, 30), 2, "#b46cff");
        tc(.3, .55);
      } },
      { t: .34, fn: (a, m) => {
        const px = a.x + m.ux * 10, py = a.y + m.uy * 10, th = Math.atan2(m.uy, m.ux);
        beam({ x: px, y: py, z: 30, th, len: 440, w: 24, life: .95, pal: "purple" });
        Rt("explosions/plasma-explosion", { x: px + m.ux * 18, y: py + m.uy * 18, z: 30, rate: 1.7, palette: HEX.purple, prio: 2 });
        for (let i = 1; i <= 5; i++) Rn(i * .13, () => { W0(6.5, .16, m.ux, 0); Rt("explosions/small-explosion", { x: px + m.ux * (50 + i * 70), y: py + m.uy * (50 + i * 70), z: 10, rate: 1.8, palette: HEX.purple, prio: 1 }); });
        ring(px + m.ux * 30, py + m.uy * 30, "purple", 6, 110, .6, 5, 30);
        crack(px + m.ux * 220, py + m.uy * 220, 26, "purple", .9, { n: 11, scale: 1.8 });
        streak(px, py, 30, "purple", .5, { n: 34, speed: 260 });
        S.inv = Math.max(S.inv, .08); R2(.16); as("#d08cff", .45, 6); a3(3); $U(1.2); su(80, 1);
      } },
    ],
    sfx: [{ t: -.3, id: "gojoPurple" }, { t: .34, id: "gojoBeam" }]
  }, { range: 430, tag: "Xuyên · Tuyệt đối", show: { fx: "arcane/arcane-beam", opts: PAL.purple } });

  Yt("gojoU", "gojo", 7, "Lĩnh Vực · Vô Lượng Không Xứ", 0, 0, "Tuyệt kỹ. Mở Lĩnh Vực: mọi kẻ địch trong tầm mắt chìm trong vũ trụ thông tin vô hạn, bị tê liệt gần 6 giây và chịu sát thương liên tục.", {
    track: [[-.5, GP({ crouch: 4, lean: -2, fx: 5, fy: -21, bx: -2, by: -18 })], [-.2, GP({ crouch: 5, lean: -4, fx: 16, fy: -32, bx: 14, by: -31, armsFront: !0 })],
      [0, GP({ crouch: 5, lean: -2, fx: 22, fy: -33, bx: 19, by: -32, armsFront: !0, ghost: 1 }), "snap"], [1.1, GP({ crouch: 5, lean: -2, fx: 22, fy: -33, bx: 19, by: -32, armsFront: !0 })], [1.4, GP({})]],
    lead: .5, end: 1.4, cancel: 1.3, armorT: 1.8,
    on: [{ t: -.5, fn: (a, m) => {
      a.eyesT = 7; a.invuln = Math.max(a.invuln, 3.2);
      say("domain", { ms: 4200 });
      near(a) && (R2(.18), W0(4, .5), a3(3));
      tc(.35, 1.3);
      ring(a.x, a.y, "blue", 4, 130, .9, 4); ring(a.x, a.y, "purple", 4, 200, 1.1, 3);
      Rt("arcane/magic-circle-cast", { x: a.x, y: a.y, rate: .8, palette: HEX.blue, prio: 2, ground: !0 });
      Rn(.5, () => {
        S.dom = { x: a.x, y: a.y, t: 0, dur: 6.4 }; S.stars = null; S.inv = Math.max(S.inv, .08);
        a.local && o3(SX(a.x), SY(a.y, 20), 3, "#9fb4ff");
        crack(a.x, a.y, 24, "blue", 1.1, { n: 14, scale: 2.4 });
        streak(a.x, a.y, 24, "blue", .7, { n: 40, speed: 320 });
        as("#ffffff", .7, 4); $U(1.2);
        Rt("arcane/time-stop", { x: a.x, y: a.y, abs: !0, rate: .6, palette: HEX.purple, prio: 2 });
        ze(a, { x: a.x, y: a.y, el: "gojo", hits: [{ t: .05, rx: 620, ry: 330, zmax: 200, hit: { dmg: .5 * m.power, push: 0, status: { id: "stop", dur: 6 }, stun: 6, stop: .06, shake: 3, fx: null }, shake: 5, flash: .3 }] });
        for (let i = 0; i < 9; i++) Rn(.9 + i * .55, () => {
          if (!S.dom) return;
          ze(a, { x: a.x, y: a.y, el: "gojo", hits: [{ t: 0, rx: 620, ry: 330, zmax: 200, hit: { dmg: .85 * m.power, push: 0, stun: 6, stop: .03, shake: 2, fx: "impacts/hit-flash" }, shake: 2.5, flash: .1 }] });
          near(a) && (S.inv = Math.max(S.inv, .04), a3(2));
        });
        Rn(5.9, () => {
          ze(a, { x: a.x, y: a.y, el: "gojo", hits: [{ t: 0, rx: 640, ry: 340, zmax: 220, hit: { dmg: 6.5 * m.power, push: 0, lift: 220, stun: 1.2, stop: .16, heavy: !0, fx: "impacts/crit-hit" }, shake: 10, flash: .5, sfx: "gojoBlueEnd" }] });
          crack(a.x, a.y, 24, "purple", 1, { n: 16, scale: 3 }); S.inv = Math.max(S.inv, .09); as("#ffffff", .8, 3);
        });
        ot("sfx", "gojoDomain", a);
      });
    } }], sfx: []
  }, { range: 300, tag: "Lĩnh vực", show: { fx: "arcane/time-stop", opts: PAL.purple } });

  /* ---------- hero integration ---------- */
  const hold = {
    input(h, pressed, dt) {
      if (pressed) { h.gjHold = 0; h.gjArmed = !0; return !0; }
      const down = pt.down.attack;
      if (down && h.gjArmed && !h.dead) {
        h.gjHold += dt;
        if (h.gjHold > .3 && h.canAct && h.st !== "dash") {
          if (!h.gjCharging) {
            h.gjCharging = !0; h.cancelMove?.(!1);
            h.gjOrb = orb(h.x, h.y, 24, "blue", 99, () => 3, { spin: 14 });
            ot("sfx", "gojoCharge", h); say("hold", { ms: 1500 });
          }
          const lv = h.gjHold > .95 ? 2 : h.gjHold > .6 ? 1 : 0;
          h.gjLv = lv;
          h.intent.mx = h.intent.my = 0;
          const o = h.gjOrb; o.age = 0; o.life = 99; o.x = h.x + h.face * 17; o.y = h.y; o.z = 24;
          o.r = () => 3 + Math.min(1.4, h.gjHold - .3) * 6 + Math.sin(S.t * 30) * .8; o.pal = lv >= 2 ? "purple" : lv ? "red" : "blue";
          if (Math.floor(h.gjHold * 14) !== Math.floor((h.gjHold - dt) * 14)) {
            ring(h.x, h.y, o.pal, 40, 6, .22, 2, 8);
            if (lv && Math.floor(h.gjHold * 7) !== Math.floor((h.gjHold - dt) * 7)) { ot("sfx", "gojoCharge", h); W0(.8 + lv, .1); }
          }
        }
        return !1;
      }
      if (h.gjCharging) {
        h.gjCharging = !1; if (h.gjOrb) { h.gjOrb.life = 0; h.gjOrb.age = 1; h.gjOrb = null; }
        if (h.gjHold > .38) { const lv = h.gjHold > .95 ? 1 : 0; const aim = h.strikeAim ? h.strikeAim(220) : {}; Yi(h, lv ? "gjH2" : "gjH1", { aim: aim.tgt, th: aim.th }); h.chainI = -1; }
      }
      h.gjArmed = !1; h.gjHold = 0;
      return !1;
    },
    chargePose(h) {
      const sh = Math.floor(h.gjHold * 24) % 2;
      return GP({ crouch: 5 + (h.gjLv ?? 0), lean: -4 - (h.gjLv ?? 0), fx: 17 + sh, fy: -27, bx: 3, by: -21, ffx: 9, fbx: -8, ghost: h.gjLv >= 2 ? 1 : 0 });
    },
    hover(h, dt) {
      if (h.z <= 0) { h.hov = 0; return; }
      if (h.z > 3 && h.vz < 40 && pt.down.jump && (h.hov ?? 0) < 1.15 && !h.plunge && h.st === "jump") {
        h.vz = Math.max(h.vz, -34); h.hov = (h.hov ?? 0) + dt;
        if (Math.floor(h.hov * 9) !== Math.floor((h.hov - dt) * 9)) ring(h.x, h.y, "blue", 4, 22, .3, 2, 0);
      }
    },
    dashFx(h) {
      Rt("arcane/blink-out", { x: h.x, y: h.y, bias: 1, rate: 2, palette: HEX.blue, prio: 1, who: h });
      ring(h.x, h.y, "blue", 3, 30, .28, 2);
      streak(h.x, h.y, 20, "blue", .25, { n: 12, speed: 110 });
      Rn(.2, () => { if (!h.gone) Rt("arcane/blink-in", { x: h.x, y: h.y, bias: 1, rate: 2, palette: HEX.blue, prio: 1, who: h }); });
      ot("sfx", "gojoBlink", h);
    },
    mugen(h, t) {
      if (!h.local || Y.t < (h.mugenAt ?? 0) || !(t.dmg > 0)) return !1;
      h.mugenAt = Y.t + 8; h.gjBlockT = S.t;
      ring(h.x, h.y, "blue", 6, 52, .45, 4); ring(h.x, h.y, "blue", 3, 36, .3, 3);
      streak(h.x, h.y, 20, "blue", .25, { n: 14, speed: 90 });
      Rt("impacts/shield-block", { x: h.x, y: h.y + 1, z: 22, palette: HEX.blue, prio: 2, flip: (t.dir ?? 1) > 0 });
      ot("sfx", "gojoBlock", h); W0(2, .12);
      if (t.by && !t.by.dead) c2(h, t.by, { dmg: 0, push: 170, stun: .5, stop: .06, shake: 2, fx: null }, t.dir ?? h.face);
      ot("word", "Vô hạn", h, "gojo");
      return !0;
    },
  };

  /* ---------- skill icons (generated pixel art) ---------- */
  let iconUrl = null;
  function icons() {
    if (iconUrl) return iconUrl;
    const c = document.createElement("canvas"); c.width = 168; c.height = 24;
    const g = c.getContext("2d"), im = g.createImageData(168, 24), d = new Uint32Array(im.data.buffer);
    const put = (ox, x, y, col) => { if (x >= 0 && y >= 0 && x < 24 && y < 24) d[y * 168 + ox + x] = 0xFF000000 | (col[2] << 16) | (col[1] << 8) | col[0]; };
    const sphere = (ox, cx, cy, r, P) => { for (let y = 0; y < 24; y++) for (let x = 0; x < 24; x++) { const dd = Math.hypot(x - cx, y - cy) / r; if (dd > 1) continue; const l = (1 - dd) * .85 - ((x - cx) + (y - cy)) / (r * 7) + dith(x, y) * .25; put(ox, x, y, P[Math.floor(clamp(l * 6.99 + 1, 0, 6.99))]); } };
    for (let i = 0; i < 7; i++) {
      const ox = i * 24;
      for (let y = 0; y < 24; y++) for (let x = 0; x < 24; x++) { const dd = Math.hypot(x - 11.5, y - 11.5); put(ox, x, y, dd > 11.6 ? [0, 0, 0] : dd > 10 ? RGB.blue[2] : [10, 12 + (y >> 1), 30 + y]); }
      if (i === 0) { sphere(ox, 12, 12, 7, RGB.blue); for (let a = 0; a < 6.3; a += .15) put(ox, Math.round(12 + Math.cos(a) * 9.5), Math.round(12 + Math.sin(a) * 4), RGB.blue[5]); }
      if (i === 1) { sphere(ox, 12, 12, 7, RGB.red); for (let k = 0; k < 8; k++) { const a = k * .785; put(ox, Math.round(12 + Math.cos(a) * 10), Math.round(12 + Math.sin(a) * 10), RGB.red[5]); } }
      if (i === 2) { for (let k = 0; k < 20; k++) { put(ox, 3 + k, 19 - k, [255, 255, 255]); put(ox, 4 + k, 19 - k, RGB.blue[4]); put(ox, 2 + k, 19 - k, RGB.blue[3]); } for (let k = 0; k < 5; k++) { put(ox, 16 + k, 5 + k, RGB.blue[5]); put(ox, 16 + k, 13 - k, RGB.blue[5]); } }
      if (i === 3) { for (let r = 3; r <= 10; r += 3) for (let a = 0; a < 6.3; a += .08) put(ox, Math.round(12 + Math.cos(a) * r), Math.round(12 + Math.sin(a) * r), RGB.blue[r > 8 ? 3 : r > 5 ? 4 : 6]); }
      if (i === 4) { for (let k = -7; k <= 7; k++) for (let w = -2; w <= 2; w++) { put(ox, 12 + k, 12 + w, [140, 255, 190]); put(ox, 12 + w, 12 + k, [140, 255, 190]); } put(ox, 12, 12, [255, 255, 255]); }
      if (i === 5) { sphere(ox, 12, 12, 8, RGB.purple); for (let y = 0; y < 24; y++) for (let x = 0; x < 24; x++) { if (Math.hypot(x - 12, y - 12) < 8 && (x + y) % 5 === 0) put(ox, x, y, x < 12 ? RGB.blue[5] : RGB.red[4]); } }
      if (i === 6) { for (let y = 0; y < 24; y++) for (let x = 0; x < 24; x++) { if (Math.hypot(x - 11.5, y - 11.5) < 10 && hash(x, y) > .9) put(ox, x, y, [255, 255, 255]); } for (let x = 4; x < 20; x++) { const h = Math.round(Math.sin((x - 4) / 15 * Math.PI) * 5); put(ox, x, 12 - h, RGB.void[7]); put(ox, x, 12 + h, RGB.void[7]); } sphere(ox, 12, 12, 3, RGB.purple); put(ox, 12, 12, [255, 255, 255]); }
    }
    g.putImageData(im, 0, 0); iconUrl = c.toDataURL();
    return iconUrl;
  }

  /* ---------- unlock via code ---------- */
  function unlock(silent) {
    const s = Y.save; if (!s) return !1;
    const first = !s.gojo;
    s.gojo = 1; if (!na.includes("gojo")) na.push("gojo");
    if (!s.load) s.load = {};
    if (!s.load.gojo) s.load.gojo = [];
    for (const id of ss.gojo) if (id) s.skills[id] = 1;
    if (first || !s.load.gojo.length) s.load.gojo = ["gojo1", "gojo2", "gojo6", "gojo3"];
    s.el = "gojo"; Pn(); q0();
    const me = Y.me;
    if (me && me.setElement) { me.setElement("gojo"); me.chainI = -1; }
    if (!silent) {
      say("honored", { ms: 4200 });
      ot("toast", "Đã mở khóa Gojo Satoru!", "good");
      ot("banner", "Gojo Satoru", "Lục Nhãn · Vô Hạ Hạn", "ult", "gojo");
      if (me) { ring(me.x, me.y, "blue", 6, 120, .9, 4); streak(me.x, me.y, 22, "blue", .6, { n: 36, speed: 260 }); W0(4, .4); as("#bff0ff", .6, 5); }
    }
    return !0;
  }
  function redeem(raw) {
    const c = String(raw || "").trim().toLowerCase().replace(/\s+/g, "");
    if (c === "gojo" || c === "gojosatoru" || c === "satorugojo" || c === "六眼") return unlock();
    ot("toast", "Mã không đúng", "warn"); return !1;
  }
  function codeRow() {
    const wrap = document.createElement("div"); wrap.className = "gj-code";
    const lab = document.createElement("div"); lab.className = "t9 c-dim"; lab.textContent = "Nhập mã nhân vật";
    const row = document.createElement("div"); row.className = "gj-row";
    const inp = document.createElement("input"); inp.type = "text"; inp.placeholder = "Nhập mã…"; inp.autocomplete = "off"; inp.autocapitalize = "off"; inp.spellcheck = !1; inp.maxLength = 24; inp.setAttribute("aria-label", "Nhập mã");
    const btn = ce("Nhận", () => { if (redeem(inp.value)) inp.value = ""; }, "sm");
    inp.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); btn.click(); } e.stopPropagation(); });
    row.append(inp, btn); wrap.append(lab, row);
    if (Y.save?.gojo) { const ok = document.createElement("div"); ok.className = "t7 c-el"; ok.textContent = "Gojo Satoru đã mở khóa. Đổi hệ bằng nút đổi hành."; wrap.append(ok); }
    return wrap;
  }

  _t("frame", dt => { S.dt = dt; S.t += dt; for (const p of Y.players) if (p.eyesT > 0) p.eyesT -= dt; if (S.inv > 0) S.inv -= dt; for (const o of fxs) { o.age += dt; if (o.step) o.step(o, dt); } if (S.dom) { S.dom.t += dt; if (S.dom.t >= S.dom.dur) { S.dom = null; S.stars = null; } } });
  _t("cast", (a, o) => { if (o && o.el === "gojo" && a.local && o.id !== "gojoU") ot("word", o.name.split(" · ")[0], a, "gojo"); });

  return { sfx: SFX, S, say, post, bg: domainBg, hold, icons, redeem, unlock, codeRow, ring, streak, orb, crack, beam, LINES, fxs, GP, GLOOK, filter: arr => { if (!S.dom) return; for (let i = arr.length - 1; i >= 0; i--) if (arr[i].prop) arr.splice(i, 1); } };
})();
