import fs from "node:fs";
import { buildSync } from "esbuild";
let s = fs.readFileSync("game-src/base.js", "utf8");
const gojo = fs.readFileSync("game-src/gojo.js", "utf8");
const rep = (a, b, label) => {
  const n = s.split(a).length - 1;
  if (n !== 1) throw new Error("patch '" + label + "' matched " + n + " times");
  s = s.replace(a, () => b);
};
const rx = (re, b, label) => {
  const m = s.match(re);
  if (!m) throw new Error("patch '" + label + "' no match");
  s = s.replace(re, (...m) => b.replace(/\$(\d)/g, (x, d) => m[d]));
};
// 1 module insertion (after looks table, before hero class)
rep('    var xft = [X("#b3342c"), X("#781f1c")],', gojo + '\n    window.__GJ = GJ; window.__Y = Y;\n    var xft = [X("#b3342c"), X("#781f1c")],', "module");
// 2 gear branch
rep('p.includes("mask") && O1(ue(x.t, Se(x.R, g(1.5, -.3, 0))), x.R, g(2, 2.6, 2.3), oe.extra, 0),',
`if (p.includes("gojo")) {
      const sp = (A, B, ra, rb) => Gs(ue(x.t, Se(x.R, g(...A))), ue(x.t, Se(x.R, g(...B))), ra * u, rb * u, oe.hair, 0);
      O1(ue(x.t, Se(x.R, g(-.5, 1.1, 0))), x.R, g(3.25, 3.35, 3.15), oe.hair, 0);
      for (const sd of [1, -1]) { sp([1, 2.7, sd * 1.7], [2.9, 6, sd * 2.6], 1.3, .35); sp([-1.2, 2.7, sd * 1.9], [-2.8, 5.8, sd * 3.2], 1.3, .35); sp([-2, 1.3, sd * 1.4], [-5.2, 3.4, sd * 2.3], 1.2, .3); sp([.2, 3, sd * .8], [.6, 6.8, sd * 1.1], 1.3, .3); }
      sp([.6, 3.1, 0], [1.9, 7.4, 0], 1.5, .3); sp([-1.2, 2.8, 0], [-3.6, 6.4, 0], 1.4, .3); sp([-2.2, 1, 0], [-5.4, 1.6, 0], 1.3, .3);
      if (p.includes("eyes")) { for (const sd of [1, -1]) D1(ue(x.t, Se(x.R, g(2.95, .55, sd * 1.15))), .8 * u, oe.hat, 0) }
      else O1(ue(x.t, Se(x.R, g(.35, .75, 0))), x.R, g(3.12, .95, 2.98), oe.extra, 0);
      O1(ue(l("neck").t, Se(l("chest").R, g(-.2, .5, 0))), l("chest").R, g(2.7, 1.9, 3.5), oe.chest, 0)
    }
    p.includes("mask") && O1(ue(x.t, Se(x.R, g(1.5, -.3, 0))), x.R, g(2, 2.6, 2.3), oe.extra, 0),`, "gear");
// 3 hero class
rep('setWeapon(t) {\n       this.kind = Fn[t] ? t : "fist"\n      }', 'setWeapon(t) {\n       this.kind = this.el === "gojo" ? "gojo" : Fn[t] ? t : "fist"\n      }', "setWeapon");
rx(/paint\(\) \{\n(\s*)let t = Pt\[this\.el\];/, 'paint() {\n$1this.hero && (this.look = this.el === "gojo" ? GJ.GLOOK : _s[this.lookId] ?? _s[0], this.gjSync());\n$1let t = Pt[this.el];', "paint");
rep('      setElement(t, e = !1) {', `      gjSync() {
       if (this.el === "gojo") { this.kind !== "gojo" && this.setWeapon("gojo"), this.weaponMap = null }
       else if (this.kind === "gojo") { if (this.local) { let n = lh(); this.kind = n && Fn[n.kind] ? n.kind : "fist", this.weaponMap = n ? YE(Fs[n.rar].ramp) : null } else this.kind = "fist" }
      }
      setElement(t, e = !1) {`, "gjSync");
rep('this.khiRegen = 4.5 * (t === "thuy" ? 1.25 : 1)', 'this.khiRegen = 4.5 * (t === "thuy" ? 1.25 : 1) * (t === "gojo" ? 1.7 : 1)', "khi");
rx(/takeHit\(t\) \{\n(\s*)let e = this\.hp;\n(\s*)super\.takeHit\(t\), this\.local/, 'takeHit(t) {\n$1if (this.el === "gojo" && GJ.hold.mugen(this, t)) return;\n$1let e = this.hp;\n$2super.takeHit(t), this.local', "takeHit");
rep('(T0("attack") || pt.down.attack && pt.held.attack > .24 && this.canAct && this.st !== "dash") && this.attack()', '(this.el === "gojo" ? GJ.hold.input(this, T0("attack"), t) : T0("attack") || pt.down.attack && pt.held.attack > .24 && this.canAct && this.st !== "dash") && this.attack()', "attackInput");
rep('T0("jump") && this.jump(), this.sprint', 'T0("jump") && this.jump(), this.el === "gojo" && GJ.hold.hover(this, t), this.sprint', "hover");
rx(/f2\(this, t, e, \{\n\s*speed: 310,\n\s*dur: \.24,\n\s*inv: \.27\n\s*\}\)/, 'this.el === "gojo" ? (GJ.hold.dashFx(this), f2(this, t, e, { speed: 470, dur: .2, inv: .34 })) : f2(this, t, e, { speed: 310, dur: .24, inv: .27 })', "dodge");
rep('this.cancelMove(!1), this.vz = yft, this.z = 1', 'this.cancelMove(!1), this.vz = yft * (this.el === "gojo" ? 1.15 : 1), this.z = 1', "jump");
rx(/default:\n(\s*)n = c3\(e, this\.animT, this\.calm\)/, 'default:\n$1n = this.gjCharging ? GJ.hold.chargePose(this) : c3(e, this.animT, this.calm)', "idlePose");
rep('this.scarf && q1t(this, t);', 'this.scarf && this.el !== "gojo" && q1t(this, t);', "scarfDraw");
rep('let e = this.look?.gear;', 'let e = this.look?.gear;\n       this.eyesT > 0 && e === "gojo" && (e = "gojo,eyes");', "geared");
rep("let o = Ou[a];", "let o = Ou[a] ?? GJ.sfx[a];", "sfxLookup");
// 4 render hooks
rep('JU(), t.drawGround(a), i_(a);', 'JU(), t.drawGround(a), i_(a), GJ.bg(a);', "bg");
rep('r_(e), e.sort(qft);', 'r_(e), GJ.filter(e), e.sort(qft);', "filter");
rep('Xft(a), gj(a), c_(a), l_(a), ZU()', 'Xft(a), gj(a), c_(a), l_(a), GJ.post(a), ZU()', "post");
// 5 save
rep('for (let n of na)(e = a.load)[n] ?? (e[n] = [])', 'a.gojo && !na.includes("gojo") && na.push("gojo");\n      for (let n of na)(e = a.load)[n] ?? (e[n] = [])', "save");
// 6 icons
rx(/return e\.style\.backgroundPosition = `calc\(var\(--u\) \* \$\{-24\*\(t\.slot-1\)\}\) calc\(var\(--u\) \* \$\{-24\*na\.indexOf\(t\.el\)\}\)`, e/, 'return t.el === "gojo" ? (e.style.backgroundImage = "url(" + GJ.icons() + ")", e.style.backgroundSize = "calc(var(--u) * 168) calc(var(--u) * 24)", e.style.backgroundPosition = `calc(var(--u) * ${-24*(t.slot-1)}) 0`, e) : (e.style.backgroundPosition = `calc(var(--u) * ${-24*(t.slot-1)}) calc(var(--u) * ${-24*na.indexOf(t.el)})`, e)', "icon");
// 7 settings + controls
rep('e.append(tt("div", "sep"), c), a.body.append(e)', 'e.append(tt("div", "sep"), c, GJ.codeRow()), a.body.append(e)', "codeRow");
rep('["Trò chuyện (trong phòng)", "T", "↓"]', '["Trò chuyện (trong phòng)", "T", "↓"],\n       ["Gojo: giữ nút đánh · giữ nhảy", "Giữ J · giữ Space", "Giữ X · giữ Ấn cần"]', "controls");
// 8 network: TURN fallbacks
rep('urls: "stun:stun.cloudflare.com:3478"\n     }],', 'urls: "stun:stun.cloudflare.com:3478"\n     }, {\n      urls: ["turn:openrelay.metered.ca:80", "turn:openrelay.metered.ca:443", "turn:openrelay.metered.ca:443?transport=tcp", "turns:openrelay.metered.ca:443?transport=tcp"],\n      username: "openrelayproject",\n      credential: "openrelayproject"\n     }],', "turn");
fs.writeFileSync("game-src/game.patched.js", s);
const out = buildSync({ entryPoints: ["game-src/game.patched.js"], outfile: "public/game/game.js", minify: true, target: "es2020", logLevel: "error", legalComments: "none" });
fs.writeFileSync("public/game/ui.css", fs.readFileSync("game-src/ui.css", "utf8") + "\n" + fs.readFileSync("game-src/gojo.css", "utf8"));
let html = fs.readFileSync("game-src/index.html", "utf8");
html = html.replace('<meta charset="utf-8">', '<meta charset="utf-8">\n<base href="/game/">').replace(/\?v=\d+/g, "?v=" + Date.now().toString(36));
fs.writeFileSync("public/game/index.html", html);
fs.copyFileSync("game-src/pixelfx-LICENSE", "public/game/pixelfx-LICENSE");
fs.copyFileSync("game-src/pixelfx-NOTICE.md", "public/game/pixelfx-NOTICE.md");
console.log("built", fs.statSync("public/game/game.js").size);
