import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

// The static game itself needs no database. Only open the optional DB on request.
export async function GET() {
  if (!process.env.DATABASE_URL) return Response.json({ ok: false, reason: "DATABASE_URL is not configured" }, { status: 503 });
  try {
    const { db } = await import("@/db");
    await db.execute(sql`select 1`);
    return Response.json({ ok: true });
  } catch {
    return Response.json({ ok: false }, { status: 500 });
  }
}
