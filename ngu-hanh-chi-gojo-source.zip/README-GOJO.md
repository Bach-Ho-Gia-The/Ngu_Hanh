# Ngũ Hành – bản develop với Gojo đã sửa

Nguồn: `develop-elemental-pixel-combat-game.zip` từ repository `Bach-Ho-Gia-The/Ngu_Hanh`, commit `eb1d2d4`. Gojo, animation và bộ chiêu được giữ theo module trong bản develop này; không dùng bản Gojo tự thiết kế trước đó. Các tài nguyên sprite/font còn thiếu trong ZIP gốc được phục hồi từ bản Ngũ Hành không Gojo trong cùng repository.

## Chạy và sửa
- Node.js 20 trở lên: `npm install`, sau đó `npm run build:game`, rồi `npm run dev`.
- Vào `http://localhost:3000/` (hoặc `/game/index.html`). Build Next.js: `npm run build`, sau đó `npm start`.
- Game nằm trong `public/game`; phần tích hợp nằm tại `game-src/gojo.js`, các patch build ở `game-src/build.mjs`. Chỉnh các file đó rồi chạy lại `npm run build:game`.
- Không cần PostgreSQL để chơi. Endpoint `/api/health` chỉ kiểm tra database tùy chọn; trả HTTP 503 khi chưa cấu hình `DATABASE_URL`.
- Mở Gojo: **Cài đặt → Nhập mã nhân vật → gojo → Nhận**. Mặc định Xanh, Đỏ, Tím và Thuấn Bộ nằm trên thanh chiêu; các chiêu khác ở menu Chiêu thức.

## Thay đổi chính
- Giữ nút đánh: khoảng **0,4 giây Xanh**, **1 giây Đỏ**, **2,1 giây Tím**; thả nút để bắn. Tím có vụ nổ bạo kích và impact frame tại va chạm. Cầu tích lực biến mất khi chạm mục tiêu; nhát đánh thường thứ năm không tạo thêm cầu xanh.
- Chiêu Hư Thức Tím tạo cầu lớn xoắn không gian cục bộ, rung màn hình và tạo rãnh đất lún với kết cấu neo vào tọa độ thế giới, hai bờ đá nhô lên và đá văng; sau vài giây chúng mờ dần, địa hình trở lại bình thường (hiệu ứng tạm, không phá địa hình vĩnh viễn). Khi va địch có impact frame và gây sát thương xuyên; sau va chạm đầu cầu tiếp tục bay khoảng 0,55 giây rồi mới nổ. Nếu không gặp địch, cầu nổ khi hết tầm/chạm vật cản.
- Xích có lực đẩy cả theo chiều ngang lẫn chiều dọc tại vụ nổ. Riêng hình nộm vốn đứng cố định: Đỏ giữ đánh làm trượt nhẹ, Xích kỹ năng đẩy mạnh hơn; hình nộm dừng lại ở vị trí mới thay vì tự trở về. Lãnh địa dùng nền pixel gốc tạo mới (`public/game/assets/void-nebula.png`) với dịch chuyển/lensing theo thời gian, mở từ phía địch, hố đen nhiều lớp và vệt sơn kết thúc.
- Lam và Xích mỗi chiêu dùng một cầu chính; Tím chỉ giữ hai cầu lúc hội tụ và một cầu khi hợp nhất, không chồng các cầu pixelfx lệch tâm hoặc dải cầu phụ. Hiệu ứng pixelfx vẫn dùng cho va chạm và nổ; cả hai lớp hiệu ứng được dọn sau chiêu.
- Loại animation pixelfx có hình nhân mẫu khỏi đòn Gojo và lướt; hiệu ứng đánh/lướt được giữ gần vị trí nhân vật.
- Vô Hạ Hạn đẩy địch gần trong lúc khiên hoạt động; chủ phòng điều khiển quái, tránh đẩy đồng đội.
- Infinite Void kéo dài 8,2 giây, mở từ gần địch với các tia tím hội tụ theo ảnh tham khảo rồi chuyển sang hố đen. Địch trong vùng bị khóa, không có sát thương định kỳ; sát thương trực tiếp của người dùng Gojo tăng gấp ba và mọi đòn gây sát thương của người đó đều bạo kích trong lúc lãnh địa hoạt động; hệ số bạo kích vẫn áp dụng một lần (mặc định ×1,6). Trong khoảng ba giây cuối, một nét sơn trắng quẹt ngang dần xuất hiện với chi tiết ngẫu nhiên; cuối cùng tràn trắng, impact frame và đòn kết thúc bạo kích. Màn trắng che điểm thay nền rồi mờ đi trên thế giới bình thường; khi tắt nháy sáng mức trắng được giảm để dễ chịu hơn. Không dùng hình/âm thanh anime gốc.
- Ô nhập mã giữ nguyên focus và chữ đang nhập khi bàn phím điện thoại làm đổi kích thước màn hình; phím Enter cũng nhận mã.
- Bổ sung vùng ngắm cho cả bảy chiêu: giữ nút chiêu để xem vùng, kéo để chọn hướng; thả để tung. Thuấn Bộ đánh dấu vùng tìm địch gần, chiêu phòng thủ/hồi phục hiển thị quanh người.
- Hiệu ứng tạm tự kết thúc, kể cả lúc bị ngắt/đổi nhân vật/mất điều khiển; loại cầu tụ lực bị bỏ lại khi chết hoặc bị choáng.
- Giọng tiếng Nhật tổng hợp mới, người dùng đã chọn; KHÔNG phải âm thanh từ anime hoặc giọng diễn viên. Các file nằm tại `public/game/assets/voice/`. Giọng đi theo âm lượng hiệu ứng của game; trình duyệt có thể chặn âm thanh trước thao tác đầu tiên.
- Có chuyển đổi save Gojo của nhánh cũ sang các ID Gojo của bản develop trên cùng origin, giữ tiền và màn chơi. Save ở website khác không tự chuyển qua domain mới.
- Tăng phiên bản phòng mạng để tránh trộn client có bộ chiêu không tương thích. Tất cả người trong phòng cần mở cùng bản game. Relay công cộng / TURN vẫn phụ thuộc dịch vụ bên ngoài.

## Kiểm tra
Chạy server tĩnh tại `public` trên cổng 4173 (ví dụ `python3 -m http.server 4173 --directory public`), sau đó `node tests/regression.mjs`, `node tests/skills.mjs`, `node tests/touch.mjs`, `node tests/network.mjs` và `node tests/unlock.mjs`, `node tests/mobile-keyboard.mjs` và `node tests/mobile-keyboard-ingame.mjs`, `node tests/fx-acceptance.mjs`, `node tests/interrupt-and-domain.mjs`, `node tests/spheres.mjs`, `node tests/void-realtime.mjs`, `node tests/combat-overhaul.mjs`, `node tests/charge-impact.mjs`, `node tests/purple-pierce.mjs`, `node tests/touch-charge.mjs`, `node tests/red-dummy-position.mjs`, `node tests/domain-purple-v2.mjs`, `node tests/terrain-ink-v3.mjs`. Playwright cần các browser tương ứng. `ENGINE=webkit node tests/regression.mjs` và `ENGINE=webkit node tests/mobile-keyboard.mjs` kiểm tra WebKit.

## VFX và cân bằng bản mới
Xem `README-VFX-GOJO.md` để biết nguồn, nhịp VFX và phép thử sát thương. Thay đổi Xanh gồm cầu có lõi xoáy và nhiều luồng hút chuyển động vào tâm; Đỏ có vệt chuyển động và xung nổ, hiệu ứng phòng vệ/hồi phục có thêm chuyển động phụ. Kết cấu rãnh Tím được kiểm tra tại cùng tọa độ thế giới sau khi camera dịch.

Các test bổ sung: `node tests/camera-anchoring.mjs`, `node tests/domain-crit-transition.mjs`, `node tests/domain-skills-crit.mjs`, `node tests/balance-gojo.mjs`. Test mạng kiểm tra thực tế người khách đánh chí mạng lên quái do chủ phòng quản lý.


## Bản chỉ có Gojo
Đã bỏ Yuji/Sukuna và chức năng chuyển dạng; giữ lại phần Xanh mới, gồm lõi xoắn và khúc xạ cục bộ. Nếu mở save của bản thử nghiệm Yuji/Sukuna trên cùng origin, nhân vật đang chọn sẽ chuyển sang Gojo mà không xóa tiến trình. Phòng mạng phiên bản 15 cần các người chơi dùng cùng bản.
