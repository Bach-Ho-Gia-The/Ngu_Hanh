# Thiết kế VFX và cân bằng Gojo

## Tài liệu tham khảo
- Riot Games, *League of Legends VFX Style Guide*: hình chính phải đọc rõ, phụ trợ ít tương phản hơn, độ quan trọng và vùng hiệu lực phải thể hiện qua hình dáng, giá trị sáng/tối, màu và thời điểm: https://f.rpghq.org/F9aMk130UkIq.pdf?n=League+of+Legends+Riot+Games+-+Spell+visual+effects+color+art+guide.pdf
- VFXDoc, *Authoring VFX*: kết hợp nhiều cỡ hạt, tốc độ và nhịp; chủ đích phản hồi và thứ tự anticipation–attack–decay: https://vfxdoc.readthedocs.io/en/latest/vfx/authoringvfx/
- Riot Beardilocks, *Anatomy of a League of Legends missile*: VFX cần cho biết chiêu nào, tác dụng và độ mạnh; ánh sáng ở đầu đạn tạo thứ bậc nhìn: https://realtimevfx.com/t/anatomy-of-a-league-of-legends-missile-part-2-what-are-we-communicating-with-our-vfx/13062 và https://realtimevfx.com/t/collection-of-stylized-vfx/11545
- Jujutsu Kaisen: Xanh hội tụ/hút, Đỏ phân kỳ/đẩy, Tím kết hợp hai lực; Lãnh địa vô hiệu hóa bằng quá tải thông tin: https://www.cbr.com/jjk-gojo-every-cursed-technique/ và https://koopermagazine.com/unlimited-void/

Đây là phân tích và thiết kế mới cho game pixel, không sử dụng video/âm thanh anime hay khẳng định sao chép chính xác từng khung hình anime.

## Phân cấp và nhịp
- Xanh: hình chính là điểm kỳ dị xanh đậm + lõi sáng, ánh sáng khu trú và các hạt nhiều cỡ chuyển động hướng vào tâm. Có hành trình tới điểm ngắm, nhịp nén, sau đó co sụp và xung thoát nhanh. Vùng hút vẫn rõ; không dùng các hiệu ứng có hình nhân mẫu.
- Đỏ: một cầu nóng sáng, tia/đốm theo hướng bay và xung tỏa ra ở thời điểm kết thúc, khác rõ với chuyển động hút của Xanh.
- Thuấn Bộ: tín hiệu biến mất, hiện ra và đòn đánh phân cấp ngắn; Vô Hạ Hạn là vòng bảo vệ nhẹ và chuyển động quỹ đạo; hồi phục dùng hạt sáng đi lên, không lấn át tấn công.
- Tím là hiệu ứng tấn công chủ lực: một cầu xuyên, biến dạng cục bộ, rãnh đất bám không gian thế giới, nổ sau va chạm. Lãnh địa là mức cao nhất nhưng phải còn nhìn được nhân vật và HUD.
- Sơn Lãnh địa mở nét trong 3 giây cuối; trắng phủ lên, nền cũ được giải phóng khi màn trắng, sau đó trắng mờ liên tục về cảnh chơi. Giảm nhấp nháy khi tắt thiết lập flash.
- Giới hạn lớp hiệu ứng tạm và dọn sau khi hết hạn, đổi cảnh hoặc bị ngắt. Kiểm tra trong trình duyệt và đo tương đối, không khẳng định hiệu năng của điện thoại vật lý.

## Quy tắc sát thương
Hệ số áp lên sức đánh trước phòng thủ, hệ, độ ngẫu nhiên, trang bị và bạo kích. Xanh là gom/khống chế, Đỏ là sát thương/đẩy lớn hơn, Tím có giá và hồi chiêu lớn nên sát thương cao hơn. Lãnh địa không tự giật sát thương trong lúc khóa, các đòn gây sát thương trực tiếp của người tung trong Lãnh địa luôn bạo kích và được nhân 3, đòn kết thúc bạo kích. Với ATK 10, crit 0, mục tiêu thật đứng trong vùng và mọi phần của chiêu trúng: một lượt đo Xanh 38, Đỏ 47, Tím 113; với giảm sát thương 50% lần lượt 20, 23, 59. Kết quả biến thiên ±8%, làm tròn từng hit, và có thể thấp hơn nếu mục tiêu thoát khỏi vùng nổ hoặc bất khả xâm phạm. Kiểm thử không chứng minh cân bằng hoàn hảo với mọi build, boss hay cách chơi.

| Kỹ năng | Năng lượng | Hồi chiêu (giây) | Hệ số sát thương chưa crit | Vai trò |
|---|---:|---:|---|---|
| Xanh | 14 | 4,5 | 0,18 mỗi nhịp (tối đa 7 nhịp trong phép đo) + 2,6 kết | hút; cần giữ mục tiêu trong vùng |
| Đỏ | 18 | 5 | 2,2 va chạm + 2,7 nổ | đẩy |
| Tím | 40 | 12 | 6,8 va chạm + 4,2 nổ | xuyên; có thể chỉ trúng một phần |
| Kết lãnh địa | tuyệt kỹ | — | 3,8 trước buff ×3 và một lần bạo kích | khóa không tick, một đòn kết |

Năm đòn đánh thường có hệ số lần lượt 0,8 / 0,95 / 1,0 / 1,2 / 1,7. Trong lãnh địa, ×3 sát thương chồng với hệ số bạo kích của nhân vật một lần; mặc định ×1,6, tức 4,8 lần đòn không crit ngoài lãnh địa trước các điều kiện khác. Đòn không gây sát thương không biến thành crit; người chơi khác và ngoài thời gian lãnh địa không nhận buff. Đòn kết giảm từ hệ số 6 xuống 3,8 để bù việc mọi đòn trong lãnh địa đều crit và tránh tăng sức mạnh tổng thể quá đột ngột.
