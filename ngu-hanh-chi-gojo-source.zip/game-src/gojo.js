/* ======================= GOJO SATORU MODULE (Lục Nhãn · Vô Hạ Hạn) =======================
 * Inserted into the game closure. Uses engine internals: Pt, ss, Yt, ie, Fn, Gi, dt, Rt (pixelfx),
 * Y, ot, _t, lt, W0, as, a3, o3, R2, tc, $U, Y0, ze, G0, Rn, ji, Ay, l2, t0, Ou, Vt, Et, X ...
 */
var GJ = (() => {
  const HEX = {
    blue: ["#020a2a", "#06246e", "#0c52d0", "#2a8cff", "#6cc8ff", "#bff0ff", "#ffffff"],
    red: ["#2a0208", "#6e0a18", "#c4162c", "#ff3a4a", "#ff8a7a", "#ffd0c0", "#ffffff"],
    purple: ["#0a0220", "#2a0a5a", "#5a1ea8", "#9a4aff", "#d08cff", "#f0d0ff", "#ffffff"],
    void: ["#02010a", "#070320", "#0f0640", "#1c0e6e", "#2e1ca0", "#4a40d0", "#8a90ff", "#e8f4ff"],
  };
  const RGB = {};
  for (const k in HEX) RGB[k] = HEX[k].map(h => { const v = X(h); return [v & 255, (v >>> 8) & 255, (v >>> 16) & 255]; });
  // Dedicated no-damage incapacitation; distinct from the game's other stop effects.
  Wi.gjVoid = { dur: .5, hold: true, name: "Vô Lượng Không Xứ", tint: [4291343520, .22] };
  const PAL = { blue: { palette: HEX.blue }, red: { palette: HEX.red }, purple: { palette: HEX.purple } };
  const B4 = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5].map(v => (v + .5) / 16);
  const clamp = (v, a = 0, b = 1) => v < a ? a : v > b ? b : v;
  const ease = k => 1 - Math.pow(1 - clamp(k), 3);
  const SX = x => Math.round(x - lt.camX), SY = (y, z = 0) => Math.round(y - lt.camY - z);

  /* ---------- Element, look, base pose ---------- */
  Pt.gojo = {
    id: "gojo", name: "Gojo", han: "眼", title: "Lục Nhãn · Vô Hạ Hạn", outer: true,
    ui: "#7fd4ff", uiDeep: "#2a52c8", ramp: HEX.blue,
    sparks: ["#ffffff", "#bff0ff", "#6cc8ff", "#2a52c8"],
    trail: ["#06246e", "#0c52d0", "#2a8cff", "#6cc8ff", "#bff0ff", "#ffffff", "#ffffff"],
    status: null,
    passive: "Vô Hạ Hạn: chặn đòn đầu tiên mỗi 8 giây. Khí hồi nhanh +70%. Giữ đánh: Xanh, Đỏ đẩy, giữ lâu lên Tím bạo kích.",
    blurb: "Kẻ mạnh nhất. Xanh hút, Đỏ đẩy, Tím xóa sổ. Lướt, bay lơ lửng và triển khai Lĩnh Vực."
  };
  ss.gojo = [];
  Fn.gojo = { ...dt, fx: 3, fy: -15, bx: -1, by: -16, crouch: 2, lean: -1, ffx: 7, fbx: -7 };
  const GP = o => ({ ...Fn.gojo, ...o });
  const GLOOK = {
    id: "gojo", name: "Gojo Satoru", gear: "gojo",
    skin: vo({
      top: "#14162e", sleeve: "#14162e", sash: "#2a3a8c", bottom: "#101224", boots: "#0b0c18",
      skin: "#f4d6c0", fore: "#f4d6c0", hand: "#f4d6c0", hair: "#f2f6ff", hat: "#bff4ff", extra: "#0a0a12", ink: "#0b0b1c", mark: "#9fe4ff"
    })
  };

  /* ---------- custom pixel FX layer (drawn into the software framebuffer) ---------- */
  const fxs = [];
  const S = { t: 0, dt: 0, inv: 0, dom: null, exit: null, stars: null };
  const addFx = o => { o.age = 0; o.world = Y.world; fxs.push(o); if (fxs.length > 36) fxs.shift(); return o; };
  const pxBlend = (f, x, y, c, a) => {
    if (x < 0 || y < 0 || x >= f.w || y >= f.h) return;
    const i = y * f.w + x, p = f.color[i], r = p & 255, g = (p >>> 8) & 255, b = (p >>> 16) & 255;
    f.color[i] = 0xFF000000 | (((b + (c[2] - b) * a) | 0) << 16) | (((g + (c[1] - g) * a) | 0) << 8) | ((r + (c[0] - r) * a) | 0);
  };
  const pxSet = (f, x, y, c) => { if (x >= 0 && y >= 0 && x < f.w && y < f.h) f.color[y * f.w + x] = 0xFF000000 | (c[2] << 16) | (c[1] << 8) | c[0]; };
  const dith = (x, y) => B4[(x & 3) + ((y & 3) << 2)];
  const hash = (a, b) => { let h = Math.imul(a | 0, 374761393) ^ Math.imul(b | 0, 668265263); h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; };

  function dLine(f, x0, y0, x1, y1, c, th = 1) {
    let dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1, e = dx + dy, n = 0;
    while (n++ < 900) {
      for (let a = 0; a < th; a++) for (let b = 0; b < th; b++) pxSet(f, x0 + a, y0 + b, c);
      if (x0 === x1 && y0 === y1) break;
      const e2 = 2 * e;
      if (e2 >= dy) { e += dy; x0 += sx; }
      if (e2 <= dx) { e += dx; y0 += sy; }
    }
  }

  function dBlendLine(f,x0,y0,x1,y1,c,alpha) {
    const dx=x1-x0,dy=y1-y0,steps=Math.min(700,Math.max(Math.abs(dx),Math.abs(dy))|0);
    if (!steps) return;
    for(let i=0;i<=steps;i++){ const k=i/steps; pxBlend(f,Math.round(x0+dx*k),Math.round(y0+dy*k),c,alpha*Math.sin(Math.PI*k)); }
  }

  function drawOrb(f, o) {
    const k = o.age / o.life, r = o.r(k, o) * (o.scale ?? 1);
    if (r < 1) return;
    const P = RGB[o.pal], cx = SX(o.x), cy = SY(o.y, o.z), R = Math.ceil(r * 1.7);
    if (cx < -R || cy < -R || cx > f.w + R || cy > f.h + R) return;
    const fade = o.fade ? 1 - clamp((k - o.fade) / (1 - o.fade)) : 1;
    for (let y = cy - R; y <= cy + R; y++) for (let x = cx - R; x <= cx + R; x++) {
      const dx = x - cx, dy = y - cy, d = Math.hypot(dx, dy) / r;
      if (d > 1.7) continue;
      if (d <= 1) {
        const sw = Math.sin(Math.atan2(dy, dx) * 3 + d * 8 - S.t * (o.spin ?? 9));
        let lit = (1 - d) * .78 + (sw * .5 + .5) * .3 * (1 - d * .4) - (dx + dy) / (r * 9);
        lit += o.heat ?? 0;
        let idx = Math.floor(clamp(lit * 6.99 + (dith(x, y) - .5) * .6, 0, 6.99));
        if (d > .9) idx = Math.min(idx, 1 + ((x + y) & 1));
        pxBlend(f, x, y, P[idx], fade);
      } else {
        const pr = (1.7 - d) / .7 * .55 * fade * (1 - k * .3);
        if (dith(x, y) < pr) pxBlend(f, x, y, P[d < 1.25 ? 4 : d < 1.5 ? 3 : 2], .8);
      }
    }
  }

  function drawRing(f, o) {
    const k = o.age / o.life, rx = o.r0 + (o.r1 - o.r0) * ease(k), th = Math.max(1, o.th * (1 - k * .6)), fl = o.flat ?? .42;
    const P = RGB[o.pal], cx = SX(o.x), cy = SY(o.y, o.z), a = 1 - k;
    const RX = Math.ceil(rx + th + 1), RY = Math.ceil(rx * fl + th + 1);
    for (let y = cy - RY; y <= cy + RY; y++) for (let x = cx - RX; x <= cx + RX; x++) {
      const e = Math.hypot((x - cx) / rx, (y - cy) / (rx * fl)), dd = Math.abs(e - 1) * rx * (1 - fl * .25);
      if (dd > th) continue;
      if (dith(x, y) > a * 1.15) continue;
      pxSet(f, x, y, P[dd < th * .35 ? 6 : dd < th * .7 ? 5 : 3]);
    }
  }

  function drawBeam(f, o) {
    const k = o.age / o.life, P = RGB[o.pal];
    const ox = o.x, oy = o.y;
    const x0 = SX(ox), y0 = SY(oy, o.z), ux = Math.cos(o.th), uy = Math.sin(o.th), L = o.len;
    const grow = ease(k * 7), env = (k < .12 ? k / .12 : k > .75 ? 1 - (k - .75) / .25 : 1);
    const w = o.w * env * (1 + .08 * Math.sin(S.t * 50));
    if (w < .5) return;
    const x1 = x0 + ux * L * grow, y1 = y0 + uy * L * grow;
    const minX = Math.max(0, Math.floor(Math.min(x0, x1) - w * 2)), maxX = Math.min(f.w - 1, Math.ceil(Math.max(x0, x1) + w * 2));
    const minY = Math.max(0, Math.floor(Math.min(y0, y1) - w * 2)), maxY = Math.min(f.h - 1, Math.ceil(Math.max(y0, y1) + w * 2));
    for (let y = minY; y <= maxY; y++) for (let x = minX; x <= maxX; x++) {
      const px = x - x0, py = y - y0, t = px * ux + py * uy;
      if (t < -w || t > L * grow + w * .6) continue;
      let d = Math.abs(-px * uy + py * ux);
      d += (hash(x >> 1, (y >> 1) + (S.t * 30 | 0)) - .5) * w * .35;
      const tw = w * (t < w ? .6 + .4 * Math.max(0, t) / w : 1) * (t > L * grow - w ? clamp((L * grow - t) / w + .3) : 1);
      const rel = d / Math.max(1, tw);
      if (rel > 1.9) continue;
      const c = rel < .32 ? 6 : rel < .6 ? 5 : rel < .9 ? 4 : rel < 1.15 ? 3 : rel < 1.5 ? 2 : 1;
      if (c <= 2 && dith(x, y) > .5) continue;
      pxSet(f, x, y, P[c]);
    }
    for (let i = 0; i < 6; i++) {
      const t = hash(i, S.t * 20 | 0) * L * grow, off = (hash(i + 9, S.t * 20 | 0) - .5) * w * 3;
      pxSet(f, Math.round(x0 + ux * t - uy * off), Math.round(y0 + uy * t + ux * off), P[6]);
    }
  }

  function drawStreaks(f, o) {
    const k = o.age / o.life, P = RGB[o.pal], cx = SX(o.x), cy = SY(o.y, o.z), n = o.n ?? 28;
    for (let i = 0; i < n; i++) {
      const a = hash(i, o.seed) * 6.2832, r0 = (o.in ?? 20) + hash(i + 50, o.seed) * 30 + k * (o.speed ?? 160) * (.6 + hash(i + 7, o.seed));
      const len = (6 + hash(i + 3, o.seed) * 26) * (1 - k);
      if (len < 1) continue;
      dLine(f, Math.round(cx + Math.cos(a) * r0), Math.round(cy + Math.sin(a) * r0 * .8), Math.round(cx + Math.cos(a) * (r0 + len)), Math.round(cy + Math.sin(a) * (r0 + len) * .8), P[hash(i, 2) > .5 ? 6 : 4]);
    }
  }

  function drawDome(f, o) {
    const h = o.follow;
    if (!h || h.dead || h.gone) { o.age = o.life; return; }
    const k = o.age / o.life, P = RGB.blue, cx = SX(h.x), cy = SY(h.y, (h.z ?? 0) + 18), R = 34 + Math.sin(S.t * 6) * 1.2, hit = clamp(1 - (S.t - (h.gjBlockT ?? -9)) * 3);
    if (k > .86 && Math.floor(S.t * 14) % 2) return;
    for (let y = Math.floor(cy - R - 2); y <= cy + R + 2; y++) for (let x = Math.floor(cx - R - 2); x <= cx + R + 2; x++) {
      const dx = x - cx, dy = (y - cy) * 1.02, d = Math.hypot(dx, dy);
      if (d > R + 1.5 || d < R - 2.5 - hit * 3) continue;
      const band = Math.sin(Math.atan2(dy, dx) * 5 + S.t * 3) * .5 + .5;
      if (dith(x, y) > .3 + band * .35 + hit * .5) continue;
      pxBlend(f, x, y, P[d > R - 1 ? (band > .6 ? 6 : 5) : 3], .75);
    }
    for(let i=0;i<9;i++){
      const a=hash(i,38)*6.283+S.t*(i%2?.8:-.65),x=Math.round(cx+Math.cos(a)*R),y=Math.round(cy+Math.sin(a)*R);
      pxBlend(f,x,y,[183,240,255],.42+hit*.38);
    }
  }
  function drawPurple(f,o) {
    const cx=SX(o.x),cy=SY(o.y,o.z),r=43,R=65;
    if(cx < -R || cy < -R || cx > f.w+R || cy > f.h+R) return;
    // Refract only a small annulus; retain the rest of the screen undistorted.
    const src=f.color.slice(), loX=Math.max(0,cx-R),hiX=Math.min(f.w-1,cx+R),loY=Math.max(0,cy-R),hiY=Math.min(f.h-1,cy+R);
    for(let y=loY;y<=hiY;y++) for(let x=loX;x<=hiX;x++) {
      const dx=x-cx,dy=y-cy,d=Math.hypot(dx,dy); if(d<r*.88||d>R)continue;
      const strength=Math.sin((d/r-.88)*Math.PI/ .65)*3.6, ang=strength/r*Math.sin(S.t*8+d*.12);
      const xx=Math.round(cx+dx*Math.cos(ang)-dy*Math.sin(ang)),yy=Math.round(cy+dx*Math.sin(ang)+dy*Math.cos(ang));
      if(xx>=0&&xx<f.w&&yy>=0&&yy<f.h) f.color[y*f.w+x]=src[yy*f.w+xx];
    }
    drawOrb(f,o);
    for(let j=0;j<3;j++){
      let last=null;
      for(let i=0;i<=50;i++){
        const a=i/50*6.283 + S.t*(j%2?2:-2)+j*2.1;
        const x=Math.round(cx+Math.cos(a)*(r+5+j*3)),y=Math.round(cy+Math.sin(a)*(r*.48+j*3)+Math.cos(a*2+S.t*6)*3);
        if(last && (i+j*7)%13<9)dBlendLine(f,last[0],last[1],x,y,j===1?[246,181,255]:[154,90,255],.7);
        last=[x,y];
      }
    }
  }
  function ground(f) {
    for(const o of fxs) if(o.kind==='purpleTrail') for(const v of o.chunks) {
      const age=S.t-v.born,fade=1-clamp((age-2.4)/1.4),rise=ease(age/.22);
      if(fade<=0)continue;
      const cx=SX(v.x),cy=SY(v.y),ux=v.ux,uy=v.uy,nx=-uy,ny=ux;
      if(cx < -90||cx>f.w+90||cy < -90||cy>f.h+90)continue;
      // The path is a recessed dirt trench, not violet scratch marks. Its dark
      // lower wall, brown exposed floor and bright broken rim suggest depth.
      for(let y=Math.floor(cy-23);y<=cy+23;y++)for(let x=Math.floor(cx-25);x<=cx+25;x++){
        const dx=x-cx,dy=y-cy,along=dx*ux+dy*uy,across=(-dx*uy+dy*ux)/.65;
        // Hash the WORLD position, not the viewport coordinate: dirt detail
        // must translate with the camera exactly like a world-space decal.
        const wx=x+Math.round(lt.camX),wy=y+Math.round(lt.camY);
        const jag=(hash(Math.floor(wx/3),Math.floor(wy/3)+v.seed)-.5)*2.2;
        const ell=Math.hypot(along/16,(across+jag)/28);
        if(ell>1.12)continue;
        const grain=hash(Math.floor(wx/2),Math.floor(wy/2)+v.seed),edge=Math.abs(across)/28;
        let c;
        if(ell>.91)c=across<0?[129,97,72]:[37,25,24];
        else if(edge>.76)c=across<0?[83,58,44]:[39,26,25];
        else c=grain>.8?[104,72,52]:grain>.38?[77,49,38]:[57,35,29];
        pxBlend(f,x,y,c,fade*(ell>.96?.62:.88));
      }
      // Adjacent broken slabs lift from BOTH banks and remain briefly, with a
      // top face, shaded thickness and cast shadow; sizes and edges vary.
      for(let side of [-1,1]) for(let j=0;j<2;j++){
        const h=hash(j+(side+1)*7,v.seed);
        if(j===1 && h<.45)continue;
        const along=(j-.5)*13+(h-.5)*17,off=side*(19+13*hash(j+22+(side+1)*9,v.seed));
        const x=Math.round(cx+ux*along+nx*off),y=Math.round(cy+uy*along+ny*off*.65);
        const width=3+(hash(j+48+(side+1)*8,v.seed)*7|0),height=(4+(hash(j+78+(side+1)*8,v.seed)*13|0))*rise;
        for(let yy=-3;yy<=3;yy++)for(let xx=-width;xx<=width;xx++)if((xx*xx)/(width*width)+yy*yy/9<=1)pxBlend(f,x+xx,y+yy,[24,17,19],fade*.58);
        for(let yy=Math.floor(-height);yy<=0;yy++)for(let xx=-width;xx<=width;xx++){
          const n=hash((xx+width)>>1,(yy+100+v.seed)>>1),shape=width*(.54+.46*Math.sin((yy+height)/Math.max(1,height)*Math.PI*.8))*(.8+.2*h);
          if(Math.abs(xx)>shape-(n>.83?1:0))continue;
          const top=yy < -height*.70,c=top?(n>.55?[159,130,105]:[127,100,80]):(xx<0?[105,75,61]:[71,51,46]);
          pxBlend(f,x+xx,y+yy,c,fade*.95);
        }
        dBlendLine(f,x-width+1,Math.round(y-height*.7),x+width-1,Math.round(y-height*.9),[186,150,117],fade*.65);
      }
      // Small displaced fragments fly outward and then fall away.
      if(age<1.2)for(let j=0;j<8;j++){
        const side=j%2?1:-1,speed=14+hash(j,v.seed)*22;
        const dx=nx*side*(18+age*speed)+ux*(hash(j+15,v.seed)-.5)*25;
        const dy=ny*side*(13+age*speed*.65)+uy*(hash(j+15,v.seed)-.5)*20;
        const z=Math.sin(Math.PI*clamp(age/1.2))*(8+hash(j+27,v.seed)*15);
        const x=Math.round(cx+dx),y=Math.round(cy+dy-z),r=2+(hash(j+40,v.seed)*3|0);
        for(let yy=0;yy<r;yy++)for(let xx=0;xx<r;xx++)if(xx+yy<r+1)pxBlend(f,x+xx,y+yy,j%2?[117,90,72]:[76,61,54],(1-age/1.2)*fade);
      }
    }
  }
  function glow(f,cx,cy,r,c,amount) {
    const R=Math.ceil(r);
    for(let y=Math.max(0,cy-R);y<=Math.min(f.h-1,cy+R);y++)for(let x=Math.max(0,cx-R);x<=Math.min(f.w-1,cx+R);x++){
      const d=Math.hypot(x-cx,y-cy)/r;if(d>=1)continue;
      const a=(1-d)*(1-d)*amount; if(a>.015)pxBlend(f,x,y,c,a);
    }
  }
  function drawBlueField(f,o) {
    const cx=SX(o.x),cy=SY(o.y,o.z),t=o.age,flight=t<.24;
    const k=clamp((t-.24)/1.05),collapse=t>1.25?clamp((t-1.25)/.20):0;
    const r=(flight?8+6*ease(t/.24):20+2.5*Math.sin(t*9))*(1-.72*collapse);
    if(cx < -60 || cy < -60 || cx>f.w+60 || cy>f.h+60)return;
    // A small, local refractive field bends the already drawn scene toward the
    // singularity. Copy once so sampling never feeds back from the same frame.
    if(!flight && collapse<.95){
      const R=Math.ceil(r*2.5),x0=Math.max(0,cx-R),x1=Math.min(f.w-1,cx+R),y0=Math.max(0,cy-R),y1=Math.min(f.h-1,cy+R);
      const sw=x1-x0+1,sh=y1-y0+1;
      if(sw>0&&sh>0){
        const copy=new Uint32Array(sw*sh);for(let y=y0;y<=y1;y++)copy.set(f.color.subarray(y*f.w+x0,y*f.w+x1+1),(y-y0)*sw);
        for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){
          const dx=x-cx,dy=y-cy,d=Math.hypot(dx,dy),u=d/r;
          if(u<1.05||u>2.35||d<1)continue;
          const strength=(1-Math.abs(u-1.7)/.65)*3.0*(1-collapse),curl=Math.sin(t*4+u*4)*.32;
          const sx=Math.max(x0,Math.min(x1,Math.round(x-(dx/d-dy/d*curl)*strength))),sy=Math.max(y0,Math.min(y1,Math.round(y-(dy/d+dx/d*curl)*strength)));
          f.color[y*f.w+x]=copy[(sy-y0)*sw+sx-x0];
        }
      }
    }
    // Primary: blue-white emission, a darker compressed centre, moving surface.
    glow(f,cx,cy,Math.round(r*2.8),[42,139,255],.43*(1-collapse));
    for(let y=cy-Math.ceil(r);y<=cy+Math.ceil(r);y++)for(let x=cx-Math.ceil(r);x<=cx+Math.ceil(r);x++){
      const dx=x-cx,dy=y-cy,d=Math.hypot(dx,dy)/r;if(d>1)continue;
      const a=Math.atan2(dy,dx),swirl=Math.sin(a*3+d*10-t*8),glint=Math.max(0,1-Math.hypot(dx+r*.22,dy+r*.25)/(r*.7));
      const value=clamp(.16+.35*(1-d)+.24*(swirl*.5+.5)+glint*.48);
      const c=value>.77?[236,253,255]:value>.57?[121,222,255]:value>.36?[37,147,244]:value>.22?[11,64,166]:[4,18,75];
      pxBlend(f,x,y,c,1-collapse*.4);
    }
    // Broken curved filaments accelerate inward, giving the singularity a
    // rotating shell and dark negative space rather than a flat circular sprite.
    for(let arm=0;arm<4;arm++){
      let last=null;
      for(let i=0;i<36;i++){
        const u=i/35,a=arm*Math.PI/2+t*1.75+u*2.4,rad=r*(.84+u*1.65);
        const x=Math.round(cx+Math.cos(a)*rad),y=Math.round(cy+Math.sin(a)*rad*.58);
        if(last && (i+arm*3)%13<10) {
          dBlendLine(f,last[0]+1,last[1]+1,x+1,y+1,[3,23,83],.72*(1-collapse));
          dBlendLine(f,last[0],last[1],x,y,arm%2?[44,139,255]:[155,231,255],(.27+.48*(1-u))*(1-collapse));
        } last=[x,y];
      }
    }
    // Two broken, tilted streams contract; particles curve IN, never radially out.
    const extent=(flight?1.45:2.6)*r;
    for(let j=0;j<22;j++){
      const cycle=(t*(.64+.24*hash(j+40,o.seed))+hash(j,o.seed))%1;
      const angle=hash(j+70,o.seed)*6.283+t*(j%2?1.5:-1.15)+(1-cycle)*.95;
      const dist=r*(1.12+(1-cycle)*1.45),tail=3+5*(1-cycle);
      const x0=Math.round(cx+Math.cos(angle)*(dist+tail)),y0=Math.round(cy+Math.sin(angle)*(dist+tail)*.68);
      const x1=Math.round(cx+Math.cos(angle)*dist),y1=Math.round(cy+Math.sin(angle)*dist*.68);
      dBlendLine(f,x0,y0,x1,y1,j%4?[75,184,255]:[221,252,255],(.18+.50*cycle)*(1-collapse));
      if(j%3===0)pxBlend(f,x1,y1,[185,245,255],.65*(1-collapse));
    }
    for(let j=0;j<2;j++){
      let last=null;
      for(let i=0;i<=45;i++){
        const a=i/45*6.283+t*(j?2.3:-1.8),rr=r*(1.1+j*.27),x=Math.round(cx+Math.cos(a)*rr),y=Math.round(cy+Math.sin(a)*rr*(j?.48:.72));
        if(last&&(i+j*4)%12<8)dBlendLine(f,last[0],last[1],x,y,j?[91,200,255]:[185,243,255],.60*(1-collapse));last=[x,y];
      }
    }
  }
  function drawEnergy(f,o) {
    const r=o.r(o.age/o.life,o)*(o.scale??1),cx=SX(o.x),cy=SY(o.y,o.z);if(r<1)return;
    const c=o.pal==='red'?[255,57,60]:[45,155,255];
    glow(f,cx,cy,Math.ceil(r*2.4),c,.33);
    drawOrb(f,o);
    if(o.projectile){
      const p=o.projectile,len=Math.hypot(p.vx,p.vy)||1,ux=p.vx/len,uy=p.vy/len;
      for(let i=0;i<10;i++){
        const phase=(S.t*(1.4+hash(i,7)) + hash(i,o.seed??59))%1,dist=r+phase*r*2.2,side=(hash(i+31,o.seed??59)-.5)*r*1.5;
        const x=Math.round(cx-ux*dist-uy*side),y=Math.round(cy-uy*dist+ux*side*.7),l=2+phase*5;
        dBlendLine(f,x,y,Math.round(x-ux*l),Math.round(y-uy*l),o.pal==='red'?[255,170,126]:[163,235,255],.50*(1-phase));
      }
    }
  }
  function drawFocusBurst(f,o) {
    const k=clamp(o.age/o.life),r=o.r0+(o.r1-o.r0)*ease(k),cx=SX(o.x),cy=SY(o.y,o.z),P=RGB[o.pal],alpha=(1-k)*(1-k);
    glow(f,cx,cy,Math.max(2,Math.round(r*1.15)),P[4],alpha*.38);
    for(let i=0;i<26;i++){
      const a=hash(i,o.seed)*6.283,rad=r*(.36+hash(i+30,o.seed)*.70),x=Math.round(cx+Math.cos(a)*rad),y=Math.round(cy+Math.sin(a)*rad*.68),len=(1-k)*(3+hash(i+40,o.seed)*13);
      dBlendLine(f,x,y,Math.round(x+Math.cos(a)*len),Math.round(y+Math.sin(a)*len*.68),P[i%4?5:6],alpha*.9);
    }
    const count=64;
    for(let i=0;i<count;i++)if((i+o.seed)%11<8){
      const a=i/count*6.283,b=(i+1)/count*6.283,rr=r*(1+.035*Math.sin(i*4+o.seed));
      dBlendLine(f,Math.round(cx+Math.cos(a)*rr),Math.round(cy+Math.sin(a)*rr*.55),Math.round(cx+Math.cos(b)*rr),Math.round(cy+Math.sin(b)*rr*.55),P[5],alpha*.75);
    }
  }
  function drawHeal(f,o){
    const h=o.follow;if(!h||h.gone)return;const cx=SX(h.x),cy=SY(h.y,12),k=o.age/o.life;
    glow(f,cx,cy,34,[110,255,185],.18*(1-k));
    for(let i=0;i<24;i++){
      const q=(k+hash(i,o.seed))%1,angle=hash(i+23,o.seed)*6.283+q*1.4,rad=7+hash(i+50,o.seed)*21;
      const x=Math.round(cx+Math.cos(angle)*rad),y=Math.round(cy+Math.sin(angle)*rad*.36-q*46),a=Math.sin(Math.PI*q)*.8*(1-k*.4);
      pxBlend(f,x,y,i%4?[153,255,201]:[246,255,246],a);
      if(i%5===0){pxBlend(f,x-1,y,[178,255,215],a*.55);pxBlend(f,x+1,y,[178,255,215],a*.55);}
    }
  }
  const fxDraw = { orb: o=>o, purple: drawPurple, ring: drawRing, beam: drawBeam, streak: drawStreaks, dome: drawDome, burst: drawFocusBurst, heal: drawHeal };
  fxDraw.orb=(f,o)=>o.singularity?drawBlueField(f,o):o.energy?drawEnergy(f,o):drawOrb(f,o);

  // Original pixel-art background; sampling it through a gentle, animated lens keeps
  // the world layered and moving instead of placing a flat screen-sized picture.
  const voidArt = { pixels: null, w: 688, h: 384 };
  const voidImage = new Image();
  voidImage.onload = () => {
    try {
      const c = document.createElement("canvas"); c.width = voidArt.w; c.height = voidArt.h;
      const ctx = c.getContext("2d", { willReadFrequently: true });
      ctx.imageSmoothingEnabled = true; ctx.drawImage(voidImage, 0, 0, c.width, c.height);
      voidArt.pixels = ctx.getImageData(0, 0, c.width, c.height).data;
    } catch (_) { voidArt.pixels = null; }
  };
  voidImage.src = new URL("assets/void-nebula.png", document.baseURI).href;

  /* ---------- Domain: Unlimited Void ---------- */
  // Cinematic drawn into the same pixel framebuffer, behind actors and combat UI.
  // Phase 1: radial expansion from the nearest enemy. Phase 2: event horizon.
  // Phase 3: advancing white ink stroke synchronized with the finishing hit.
  function domainBg(f) {
    const d = S.dom;
    if (!d) return;
    const W = f.w, H = f.h, t = d.t, col = f.color;
    const ex = clamp(SX(d.ex), W * .08, W * .92), ey = clamp(SY(d.ey, 20), H * .1, H * .9);
    const cx = W * .38, cy = H * .39, hole = Math.min(W, H) * .185;
    const maxR = Math.hypot(Math.max(ex,W-ex), Math.max(ey,H-ey)) + 10;
    const edge = maxR * ease(t / 1.65), mix = ease((t - .92) / 1.18);
    const dissolve = t > 7.7 ? 1 - ease((t - 7.7) / .5) : 1;
    d.phase = t < 1.3 ? "expansion" : t < 2.4 ? "transition" : t < 5.2 ? "void" : "ink";
    for (let by = 0; by < H; by += 3) for (let bx = 0; bx < W; bx += 3) {
      const dx = bx - ex, dy = by - ey, dist = Math.hypot(dx,dy);
      const coverage = clamp((edge - dist) / 14 + .5) * dissolve;
      if (coverage <= .005) continue;
      const ang = Math.atan2(dy, dx), speed = t * 2.8;
      // Long, thin perspective streaks converge at the opponent, not random blobs.
      const ray = Math.pow(Math.max(0, Math.sin(ang * 35 + Math.sin(ang * 9) * 1.5 + dist*.002 + speed*.32)), 16);
      const ray2 = Math.pow(Math.max(0, Math.sin(ang * 55 - speed * .2 + dist*.001)), 28);
      const halo = Math.pow(Math.max(0,Math.sin(ang * 35 + Math.sin(ang * 9) * 1.5 + dist*.002 + speed*.32)),4) * .16;
      const pulse = .55 + .45 * Math.sin(dist * .06 - t * 7);
      const fog = clamp(.48 + .26*Math.sin(dx*.025 + dy*.012 - t) + .2*Math.sin(dy*.035 - dx*.018 + t*.7));
      let r1 = 5 + fog*25 + ray * (85 + 35 * pulse) + ray2 * 35 + halo*70;
      let g1 = 3 + fog*8 + ray * 32 + ray2 * 20 + halo*22;
      let b1 = 17 + fog*48 + ray * 105 + ray2 * 55 + halo*95;
      // Layered lensing: ink-black core, cloudy accretion disk and pale-gold rim.
      const x = (bx - cx) / hole, y = (by - cy) / hole;
      const r = Math.hypot(x, y), a = Math.atan2(y, x);
      const n = .5 + .22*Math.sin(x*2.2+y*.8+t*.25) + .19*Math.sin(y*3.8-x*1.4-t*.31) + .09*Math.sin(x*6+y*4);
      const cloud = clamp(n) * Math.exp(-Math.abs(y*.65 + x*.2)) * (r > 1 ? 1 : .2);
      const swirl = .55 + .45*Math.sin(a*5 + Math.log(r+.12)*5 - t*.7);
      const outer = Math.exp(-Math.pow((r - 1.30)*4.5, 2));
      const inner = Math.exp(-Math.pow((r - 1.04)*4.2, 2)) * (.38 + .62*swirl);
      const rim = Math.exp(-Math.pow((r - 1.43)*13, 2));
      const trailY = y + .15 * x - .25 * Math.sin(x * 1.8 - t*.4);
      const mist = Math.exp(-Math.abs(trailY)*1.25) * clamp((x-.5)/1.2) * (.2 + .8*clamp(n));
      const filament = Math.pow(Math.max(0, Math.sin(y*7 + x*2.4 + Math.sin(x*2.8-t*.35))), 12) * mist;
      let r2 = 2 + cloud*42 + inner*92 + outer*35 + rim*205 + mist*25 + filament*45;
      let g2 = 4 + cloud*51 + inner*108 + outer*42 + rim*195 + mist*40 + filament*55;
      let b2 = 10 + cloud*75 + inner*129 + outer*55 + rim*165 + mist*65 + filament*65;
      if (r < .91) { r2=1;g2=2;b2=6; }
      if (voidArt.pixels) {
        const zoom = Math.min(Math.max(W/voidArt.w, H/voidArt.h), W/310) * (1.02 + .015*Math.sin(t*.6));
        let sx = (bx - W*.38)/zoom, sy = (by - H*.39)/zoom;
        const distArt = Math.hypot(sx,sy), twist = .038*Math.sin(t*.7)*Math.exp(-distArt/220);
        const cs = Math.cos(twist), sn = Math.sin(twist);
        const xx = Math.floor(216 + sx*cs - sy*sn + Math.sin(t*.47 + sy*.017)*2.2);
        const yy = Math.floor(190 + sx*sn + sy*cs + Math.sin(t*.53 + sx*.013)*1.5);
        if (xx>=0 && yy>=0 && xx<voidArt.w && yy<voidArt.h) {
          const i = (yy*voidArt.w+xx)*4, pix = voidArt.pixels;
          const glow = 1 + .05*Math.sin(t*1.4 + distArt*.025);
          r2 = pix[i]*glow; g2 = pix[i+1]*glow; b2 = pix[i+2]*glow;
        } else { r2 = 2; g2 = 4; b2 = 11; }
      }
      if (hash((bx/3)|0,(by/3)|0) > .992 && r > 1.5) { r2+=90;g2+=100;b2+=120; }
      let red = r1+(r2-r1)*mix, green = g1+(g2-g1)*mix, blue = b1+(b2-b1)*mix;
      const cr = Math.min(255,red)|0, cg = Math.min(255,green)|0, cb = Math.min(255,blue)|0;
      for (let yy=by; yy<Math.min(by+3,H); yy++) for (let xx=bx; xx<Math.min(bx+3,W); xx++) {
        const i=yy*W+xx, p=col[i], k=coverage;
        col[i]=0xFF000000 | ((((p>>>16&255)+(cb-(p>>>16&255))*k)|0)<<16) | ((((p>>>8&255)+(cg-(p>>>8&255))*k)|0)<<8) | (((p&255)+(cr-(p&255))*k)|0);
      }
    }
    drawInk(f,d);
  }

  function post(f) {
    for (let i = fxs.length - 1; i >= 0; i--) if (fxs[i].age >= fxs[i].life || (fxs[i].projectile && (fxs[i].projectile.dead || !Y.projs.includes(fxs[i].projectile)))) fxs.splice(i, 1);
    for (const o of fxs) { const fn = fxDraw[o.kind]; if (fn) fn(f, o); }
    const d = S.dom;
    if (d) {
      const W = f.w, H = f.h, col = f.color, pulse = .5 + .5 * Math.sin(d.t * 5);
      for (let y = 0; y < H; y += 2) {
        const vy = Math.abs(y / H - .5) * 2;
        if (vy < .72) continue;
        for (let x = (y >> 1) & 1; x < W; x += 2) { const i = y * W + x, p = col[i]; col[i] = 0xFF000000 | ((((p >>> 16) & 255) * .55) << 16) | ((((p >>> 8) & 255) * .55) << 8) | ((p & 255) * .55); }
      }
    }
    if (d) drawWhiteout(f,d);
    else if(S.exit && S.exit.world===Y.world) drawWhiteout(f,S.exit,true);
    if (S.inv > 0 && lt.flashScale > 0) { const col = f.color; for (let i = 0; i < col.length; i++) col[i] ^= 0x00FFFFFF; }
  }

  function drawInk(f,d) {
    const W=f.w,H=f.h,t=d.t,seed=d.seed;
    if(t < 5.2) return;
    const progressT=clamp((t-5.2)/2.05),progress=progressT*progressT*(3-2*progressT), opacity=clamp((t-5.2)/.5)*(t>7.7?1-ease((t-7.7)/.5):1);
    // One uneven brush-stroke advances left-to-right over the black-hole background.
    // Semi-continuous noise, torn edges, droplets and holes keep it organic.
    const frontier=progress*1.25-.08;
    for(let y=0;y<H;y+=2) for(let x=0;x<W;x+=2){
      const u=x/W,v=y/H, center=.57-.14*u+.015*Math.sin(u*8+seed*.01);
      const warp=.010*Math.sin(u*25+seed*.03)+.010*Math.sin(u*49-seed*.02);
      const thickness=(.027+.075*progress)*(1+.22*Math.sin(u*10+seed*.01));
      const rough=(hash((x/11)|0,seed)-.5)*.035+(hash((x/5)|0,seed+17)-.5)*.016;
      const dist=Math.abs(v-center-warp), edge=thickness+rough;
      const advance=clamp((frontier-u)*24), outside=dist-edge;
      const droplets=outside>0&&outside<.055&&hash((x/3)|0,((y/3)|0)+seed)>.987;
      const hole=dist<edge*.84&&hash((x/4)|0,((y/4)|0)+seed+43)>.975;
      const ink=advance*opacity*((dist<edge&&!hole)?1:droplets?.9:0);
      if(ink>.01)for(let yy=0;yy<2;yy++)for(let xx=0;xx<2;xx++)pxBlend(f,x+xx,y+yy,[244,246,252],ink*.97);
    }
    // Individual satellite drops cluster around the same swash, not the corners.
    for(let j=0;j<65;j++){
      const u=hash(j+80,seed), a=hash(j+110,seed)>.5?1:-1;
      if(u>frontier)continue;
      const v=.57-.14*u+.015*Math.sin(u*8+seed*.01)+a*(.06+hash(j+145,seed)*.075)*progress;
      const x=Math.round(u*W),y=Math.round(v*H),r=1+(hash(j+170,seed)*4|0);
      for(let yy=-r;yy<=r;yy++)for(let xx=-r;xx<=r;xx++)if(xx*xx+yy*yy<=r*r)pxBlend(f,x+xx,y+yy,[242,244,251],opacity*.9);
    }
  }
  function drawWhiteout(f,d,exiting=false) {
    const smooth=x=>{const u=clamp(x);return u*u*(3-2*u)};
    // Cover the change of background before the domain is released; fade the
    // overlay only after the ordinary world is already back underneath it.
    const alpha=(lt.flashScale>0?1:.42)*(exiting ? 1-smooth(d.t/.85) : smooth((d.t-7.28)/.34));
    if(alpha>.001)for(let y=0;y<f.h;y++)for(let x=0;x<f.w;x++)pxBlend(f,x,y,[255,255,255],alpha);
  }

  /* ---------- public fx helpers ---------- */
  const orb = (x, y, z, pal, life, r, extra) => addFx({ kind: "orb", x, y, z, pal, life, r, ...extra });
  const ring = (x, y, pal, r0, r1, life, th = 3, z = 0) => addFx({ kind: "ring", x, y, z, pal, r0, r1, life, th });
  const beam = (o) => addFx({ kind: "beam", pal: "purple", z: 26, w: 18, ...o });
  const flightOrb = (pr, pal, radius) => {
    const v = orb(pr.x, pr.y, pr.z, pal, .22, () => radius, { spin: 10, energy: true, seed: Math.random()*100000|0 });
    v.projectile = pr;
    v.step = () => { if (pr.dead || !Y.projs.includes(pr)) { v.life = 0; return; } v.age=0; v.x=pr.x; v.y=pr.y; v.z=pr.z; };
    return v;
  };
  const streak = (x, y, z, pal, life, extra) => addFx({ kind: "streak", x, y, z, pal, life, seed: Math.random() * 999 | 0, ...extra });
  const near = (h, r = 260) => !!Y.me && Math.abs(Y.me.x - h.x) < r;

  /* ---------- voice + subtitles ---------- */
  const LINES = {
    ao: { c: "#4aa8ff", ja: "術式順転『蒼』", rom: "Jutsushiki Juntén — Ao", vi: "Thuật thức thuận chuyển — Xanh" },
    aka: { c: "#ff4a5a", ja: "術式反転『赫』", rom: "Jutsushiki Hanten — Aka", vi: "Thuật thức phản chuyển — Đỏ" },
    murasaki: { c: "#b46cff", ja: "虚式『茈』", rom: "Kyoshiki — Murasaki", vi: "Hư thức — Tím" },
    domain: { c: "#9fb4ff", ja: "領域展開『無量空処』", rom: "Ryōiki Tenkai — Muryōkūsho", vi: "Lĩnh vực triển khai — Vô Lượng Không Xứ" },
    mugen: { c: "#7fd4ff", ja: "無下限呪術", rom: "Mukagen Jujutsu", vi: "Vô Hạ Hạn chú thuật" },
    rct: { c: "#8fffb4", ja: "反転術式", rom: "Hanten Jutsushiki", vi: "Phản chuyển thuật thức — hồi phục" },
    blink: { c: "#cfe6ff", ja: "遅いよ", rom: "Osoi yo", vi: "Chậm quá đấy~" },
    hold: { c: "#ff9a7a", ja: "ふっ飛べ", rom: "Futtobe", vi: "Bay đi!" },
    honored: { c: "#bff0ff", ja: "天上天下 唯我独尊", rom: "Tenjō tenge, yuiga dokuson", vi: "Trên trời dưới đất, duy ngã độc tôn." },
  };
  let subEl = null, subTimer = 0, currentVoice = null;
  const voiceCache = new Map();
  // Original generated Japanese speech selected by the player; never recordings from the anime.
  function playVoice(key, volume) {
    if (!LINES[key] || volume <= 0) return;
    try {
      if (currentVoice) { currentVoice.pause(); currentVoice.currentTime = 0; }
      let a = voiceCache.get(key);
      if (!a) { a = new Audio(new URL("assets/voice/" + key + ".mp3", document.baseURI).href); a.preload = "auto"; voiceCache.set(key, a); }
      a.currentTime = 0; a.volume = Math.max(0, Math.min(1, volume)); currentVoice = a;
      const playback = a.play(); if (playback && playback.catch) playback.catch(() => {});
    } catch (_) { /* Some mobile browsers block audio before a user gesture. */ }
  }
  document.addEventListener("visibilitychange", () => { if (document.hidden && currentVoice) { currentVoice.pause(); currentVoice = null; } });
  function ensureSub() {
    if (subEl) return subEl;
    subEl = document.createElement("div"); subEl.id = "gj-sub"; subEl.setAttribute("aria-live", "polite");
    subEl.innerHTML = '<div class="gj-k"></div><div class="gj-r"></div><div class="gj-v"></div>';
    (document.getElementById("ui") || document.body).appendChild(subEl);
    return subEl;
  }
  function say(key, opts = {}) {
    const L = LINES[key]; if (!L) return;
    const el = ensureSub(); el.style.setProperty("--c", L.c);
    el.querySelector(".gj-k").textContent = L.ja; el.querySelector(".gj-r").textContent = L.rom; el.querySelector(".gj-v").textContent = L.vi;
    el.classList.remove("on"); void el.offsetWidth; el.classList.add("on");
    clearTimeout(subTimer); subTimer = setTimeout(() => el.classList.remove("on"), opts.ms ?? 2600);
    const vol = Y.save?.opts?.sfx ?? .8;
    if (vol <= 0) return;
    playVoice(key, vol);
  }

  /* ---------- custom sound effects (procedural synth, same engine as the game's) ---------- */
  const SFX = {
    gojoPunch: (a, t, e) => { Et(a, 190, .12, .34 * t, { type: "sine", to: 55, pan: e }); Vt(a, 2400, .07, .3 * t, { type: "highpass", pan: e }); Et(a + .01, 1320, .09, .12 * t, { type: "triangle", to: 880, pan: e }); },
    gojoBlue: (a, t, e) => { for (let i = 0; i < 6; i++) Et(a + i * .09, 220 + i * 90, .5, .1 * t, { type: "sine", to: 900 + i * 160, pan: e }); Vt(a, 600, .9, .16 * t, { type: "bandpass", to: 3200, q: 3, pan: e }); },
    gojoBlueEnd: (a, t, e) => { Et(a, 520, .5, .38 * t, { type: "sine", to: 30, pan: e }); Vt(a, 2800, .45, .4 * t, { type: "lowpass", to: 120, q: 1, pan: e }); Et(a, 90, .7, .3 * t, { type: "square", to: 28, pan: e }); },
    gojoRed: (a, t, e) => { Et(a, 140, .35, .32 * t, { type: "sawtooth", to: 620, pan: e }); Vt(a, 1800, .3, .24 * t, { type: "bandpass", to: 700, q: 2, pan: e }); Et(a + .05, 1400, .2, .1 * t, { type: "square", to: 400, pan: e }); },
    gojoRedEnd: (a, t, e) => { Et(a, 120, .6, .6 * t, { type: "sine", to: 28, pan: e }); Vt(a, 3200, .5, .55 * t, { type: "lowpass", to: 90, q: .7, pan: e }); Vt(a + .02, 6000, .12, .3 * t, { type: "highpass", pan: e }); Et(a, 70, .8, .4 * t, { type: "square", to: 24, pan: e }); },
    gojoPurple: (a, t, e) => { for (let i = 0; i < 5; i++) { Et(a + i * .07, 110 * (1 + i * .5), .9, .12 * t, { type: "sawtooth", to: 880 * (1 + i * .25), pan: e }); } Vt(a, 400, 1, .2 * t, { type: "bandpass", to: 4200, q: 4, pan: e }); Et(a + .45, 2000, .6, .12 * t, { type: "triangle", to: 60, pan: e }); },
    gojoBeam: (a, t, e) => { Et(a, 55, 1.3, .6 * t, { type: "sawtooth", to: 38, pan: e }); Et(a, 82, 1.2, .35 * t, { type: "square", to: 41, pan: e }); Vt(a, 5000, 1.2, .5 * t, { type: "bandpass", to: 600, q: .9, pan: e }); Et(a, 880, 1.0, .12 * t, { type: "sawtooth", to: 220, pan: e }); },
    gojoDomain: (a, t, e) => { Et(a, 55, 2.2, .45 * t, { type: "sine", to: 110, pan: e }); for (let i = 0; i < 7; i++) Et(a + .1 + i * .13, 330 * Math.pow(1.5, i % 4), .9, .08 * t, { type: "triangle", to: 330 * Math.pow(1.5, i % 4) * .5, pan: e }); Vt(a, 300, 1.8, .22 * t, { type: "bandpass", to: 5000, q: 2, pan: e }); Et(a + .75, 1760, 1.2, .1 * t, { type: "sine", to: 1740, pan: e }); },
    gojoBlink: (a, t, e) => { Vt(a, 5200, .16, .32 * t, { type: "bandpass", to: 800, q: 2, pan: e }); Et(a, 1500, .14, .12 * t, { type: "sine", to: 240, pan: e }); Et(a + .1, 300, .12, .15 * t, { type: "sine", to: 900, pan: e }); },
    gojoMugen: (a, t, e) => { for (let i = 0; i < 5; i++) Et(a + i * .06, 660 * Math.pow(1.26, i), .5, .1 * t, { type: "sine", to: 660 * Math.pow(1.26, i) * 1.01, pan: e }); Vt(a, 3000, .6, .1 * t, { type: "bandpass", to: 1200, q: 6, pan: e }); },
    gojoBlock: (a, t, e) => { Et(a, 1400, .25, .22 * t, { type: "sine", to: 300, pan: e }); Vt(a, 4000, .15, .2 * t, { type: "bandpass", to: 1500, q: 4, pan: e }); Et(a + .03, 2100, .3, .1 * t, { type: "triangle", to: 2000, pan: e }); },
    gojoHeal: (a, t, e) => { for (let i = 0; i < 4; i++) Et(a + i * .08, 523 * Math.pow(1.25, i), .45, .14 * t, { type: "sine", pan: e }); },
    gojoCharge: (a, t, e) => { Et(a, 160, .3, .14 * t, { type: "sawtooth", to: 700, pan: e }); Vt(a, 900, .3, .1 * t, { type: "bandpass", to: 3000, q: 3, pan: e }); },
    gojoRelease: (a, t, e) => { Et(a, 200, .35, .5 * t, { type: "sine", to: 36, pan: e }); Vt(a, 3600, .3, .5 * t, { type: "lowpass", to: 160, pan: e }); Vt(a, 7000, .1, .25 * t, { type: "highpass", pan: e }); },
    gojoVoice: (a, t, e) => { [0, 3, 5, 3, 7, 5, 2, 0].forEach((s, i) => Et(a + i * .075, 130 * Math.pow(2, s / 12), .08, .14 * t, { type: "square", to: 130 * Math.pow(2, s / 12) * .96, pan: e })); },
  };;

  /* ---------- helpers for skill defs ---------- */
  const pulse = (m, pal = "blue", r1 = 34) => { const p = m.ahead(m.def.reach ?? 30); ring(p.x, p.y, pal, 4, r1, .34, 3, 18); };
  const gh = (h, n = 6) => { for (let i = 0; i < n; i++) h.ghosts.length < 8 && h.ghosts.push({ r: ls(h.pose), x: h.x - h.face * i * 5, y: h.y, z: h.z, flip: h.face < 0, age: i * .015, rot: h.rot }); };

  /* ---------- combo (Lục Nhãn Quyền) ---------- */
  ie("gjA1", {
    track: [[-.14, GP({ crouch: 4, lean: -2, fx: 2, fy: -17, bx: -3, by: -17 })], [-.05, GP({ crouch: 5, lean: 3, fx: 9, fy: -22, bx: -4, by: -17, x: -1 })],
      [0, GP({ x: 4, crouch: 4, lean: 7, fx: 25, fy: -27, bx: -4, by: -17, ffx: 13, fbx: -9, toeB: !0, ghost: 1 }), "snap"], [.12, GP({ x: 4, lean: 6, fx: 22, fy: -27, bx: -4, by: -17 })], [.3, GP({})]],
    lead: .1, end: .3, cancel: .14, step: 12, reach: 32,
    hits: [{ t: 0, range: 38, depth: 15, dmg: .8, push: 34, stun: .28, stop: .05, shake: 1.6, fx: "impacts/hit-spark" }],
    on: [{ t: 0, fn: (a, m) => pulse(m, "blue", 30) }], sfx: [{ t: -.02, id: "gojoPunch" }]
  });
  ie("gjA2", {
    track: [[-.15, GP({ crouch: 5, lean: -4, fx: -2, fy: -20, bx: 8, by: -22, twist: -.4 })],
      [-.04, GP({ crouch: 6, lean: -7, fx: -7, fy: -23, bx: 12, by: -25, twist: -.6, ffx: 9 })],
      [0, GP({ x: 5, crouch: 5, lean: 8, fx: -3, fy: -23, bx: 26, by: -26, armsFront: !0, ffx: 13, fbx: -10, twist: .5, ghost: 1 }), "snap"],
      [.14, GP({ x: 5, lean: 7, fx: -3, fy: -23, bx: 24, by: -26 })], [.32, GP({ x: 3 })]],
    lead: .1, end: .32, cancel: .16, step: 12, reach: 36,
    hits: [{ t: 0, range: 44, depth: 17, dmg: .95, push: 52, stun: .3, stop: .06, shake: 2, fx: "impacts/hit-spark" }],
    on: [{ t: 0, fn: (a, m) => pulse(m, "blue", 34) }], sfx: [{ t: -.02, id: "swing2" }, { t: 0, id: "gojoPunch" }]
  });
  ie("gjA3", {
    track: [[-.16, GP({ crouch: 7, lean: 3, fx: 4, fy: -17, bx: -4, by: -17, ffx: 5, ffy: 0, fbx: -6 })],
      [-.04, GP({ crouch: 11, lean: 8, fx: 7, fy: -15, bx: -5, by: -15, ffx: 8, ffy: 0, fbx: -9, twist: -.2 })],
      [0, GP({ x: 5, crouch: 10, lean: -3, fx: 3, fy: -15, bx: -4, by: -16, ffx: 24, ffy: -3, fbx: -8, toeB: !0, ghost: 1 }), "snap"],
      [.15, GP({ x: 5, crouch: 9, lean: -2, ffx: 22, ffy: -3, fx: 3, fy: -15, bx: -4, by: -16 })], [.34, GP({ x: 3 })]],
    lead: .11, end: .34, cancel: .18, step: 12, reach: 38,
    hits: [{ t: 0, range: 46, depth: 20, dmg: 1, push: 70, stun: .38, stop: .06, shake: 2.4, down: !0, fx: "impacts/hit-spark" }],
    on: [{ t: 0, fn: (a, m) => pulse(m, "blue", 38) }], sfx: [{ t: -.03, id: "swing3" }, { t: 0, id: "gojoPunch" }]
  });
  ie("gjA4", {
    track: [[-.18, GP({ crouch: 6, lean: -4, fx: 4, fy: -19, bx: -5, by: -18, ffx: 4, ffy: -3, fbx: -5 })],
      [-.04, GP({ crouch: 4, lean: -10, fx: 5, fy: -20, bx: -6, by: -20, ffx: 6, ffy: -8, fbx: -4, toeB: !0 })],
      [0, GP({ x: 5, crouch: 1, lean: -11, fx: -4, fy: -22, bx: 8, by: -30, ffx: 20, ffy: -24, fbx: -3, toeB: !0, ghost: 1 }), "snap"],
      [.16, GP({ x: 5, crouch: 1, lean: -10, fx: -4, fy: -22, bx: 8, by: -30, ffx: 19, ffy: -23 })], [.38, GP({ x: 4 })]],
    lead: .12, end: .38, cancel: .22, step: 14, reach: 40,
    hits: [{ t: 0, range: 46, depth: 20, dmg: 1.2, push: 40, lift: 240, stun: .5, stop: .08, shake: 3, heavy: !0, fx: "impacts/crit-hit" }],
    on: [{ t: 0, fn: (a, m) => { pulse(m, "blue", 44); const p = m.ahead(26); streak(p.x, p.y, 28, "blue", .22, { n: 16, speed: 90 }); } }], sfx: [{ t: -.03, id: "swing3" }, { t: 0, id: "gojoPunch" }]
  });
  ie("gjA5", {
    track: [[-.22, GP({ crouch: 6, lean: -5, fx: 3, fy: -20, bx: -2, by: -19, ffx: 5 })],
      [-.08, GP({ crouch: 7, lean: -7, fx: 4, fy: -22, bx: 3, by: -22, armsFront: !0, ffx: 9, fbx: -9, ghost: 1 })],
      [0, GP({ x: 6, crouch: 5, lean: 11, fx: 27, fy: -27, bx: 24, by: -25, armsFront: !0, ffx: 15, fbx: -11, toeB: !0, toeF: !0, ghost: 1 }), "snap"],
      [.18, GP({ x: 6, crouch: 5, lean: 10, fx: 25, fy: -27, bx: 22, by: -25, armsFront: !0 })], [.46, GP({ x: 4 })]],
    lead: .16, end: .46, cancel: .3, step: 14, reach: 44,
    fx: [{ id: "impacts/ground-slam", t: .02, ox: 36, rate: 1.6, opts: PAL.blue, sync: !1, ground: !0 }],
    hits: [{ t: 0, range: 52, depth: 26, dmg: 1.7, push: 150, lift: 90, stun: .55, stop: .1, shake: 5, heavy: !0, fx: "impacts/crit-hit" }],
    on: [{ t: 0, fn: (a, m) => {
      const p = m.ahead(30);
      ring(p.x, p.y, "blue", 6, 58, .5, 4, 20); ring(p.x, p.y, "blue", 2, 36, .35, 3, 20);
      streak(p.x, p.y, 26, "blue", .3, { n: 20, speed: 130 });
      R2(.05); $U(.6);
    } }], sfx: [{ t: -.02, id: "gojoRelease" }, { t: 0, id: "boom" }]
  });
  Gi.gojo = { chain: ["gjA1", "gjA2", "gjA3", "gjA4", "gjA5"], dash: "gjDash", name: "Lục Nhãn Quyền", blurb: "Năm đòn: chưởng, tảo, cước, hất tung và Song Chưởng đẩy sóng. Giữ nút đánh để dồn lực." };

  ie("gjDash", {
    track: [[-.1, GP({ crouch: 7, lean: 6, fx: 9, fy: -20, bx: -4, by: -19, ffx: 9, fbx: -9 })],
      [0, GP({ x: 6, crouch: 6, lean: 10, fx: 24, fy: -24, bx: -3, by: -18, ffx: 14, fbx: -11, toeB: !0, ghost: 1 }), "snap"],
      [.14, GP({ x: 6, lean: 9, fx: 22, fy: -24, bx: -3, by: -18 })], [.34, GP({ x: 3 })]],
    lead: .06, end: .34, cancel: .18, step: 26, reach: 40,
    hits: [{ t: 0, range: 50, depth: 20, dmg: 1.4, push: 110, lift: 120, stun: .45, stop: .08, shake: 3, heavy: !0, fx: "impacts/crit-hit" }],
    on: [{ t: 0, fn: (a, m) => {
      Rt("impacts/hit-spark", { follow:a, ox:18, oz:22, aim:m.th, palette:HEX.blue, rate:2.2, life:.22, prio:1 });
    } }], sfx: [{ t: -.03, id: "gojoBlink" }, { t: 0, id: "gojoPunch" }]
  });

  /* ---------- hold-attack: charge, then repulse ---------- */
  const holdDef = (lv) => ({
    track: [[-.12, GP({ crouch: 5, lean: -4, fx: 14, fy: -27, bx: 4, by: -21, ffx: 9 })],
      [0, GP({ x: 6, crouch: 5, lean: 12, fx: 28, fy: -27, bx: 25, by: -26, armsFront: !0, ffx: 15, fbx: -11, toeB: !0, toeF: !0, ghost: 1 }), "snap"],
      [.2, GP({ x: 6, lean: 11, fx: 26, fy: -27, bx: 23, by: -26, armsFront: !0 })], [.58, GP({ x: 3 })]],
    lead: .05, end: .58, cancel: .38, reach: 60, rootK: .6,
    on: [{ t: 0, fn: (a, m) => {
      const pal = ["blue", "red", "purple"][lv], size = [8, 12, 20][lv];
      const hit = { dmg: [.8,1.2,2.0][lv] * m.power, push: [150,150,260][lv], stun: .35, stop: .025, fx: "impacts/hit-spark" };
      const burstHit = { dmg: [1.4,2.4,4.4][lv] * m.power, push: [150,220,320][lv], spread: [80,140,160][lv], gjRepel: lv === 1 ? 1 : 0, lift: [30,90,170][lv], stun: [.4,.6,.9][lv], heavy: lv > 0, crit: lv === 2 ? 1 : 0, stop: lv === 2 ? .12 : .04, fx: lv === 2 ? "impacts/crit-hit" : "impacts/hit-spark" };
      const p = Y0(a, { ...d2(a,m), ...Us(m,[330,370,390][lv]), life: [.55,.62,.72][lv], r: size, el: "gojo", fx: null, pierce: 1, hit,
        burst: { fx: lv === 2 ? "explosions/plasma-explosion" : "impacts/hit-spark", opts: PAL[pal], rate: 1.6, rx: [35,60,92][lv], onFloor: !0, hit: burstHit, shake: [2,5,9][lv], flash: lv === 2 ? .22 : .08, sfx: lv === 2 ? "gojoRedEnd" : "gojoRelease" }
      });
      p.gjType = "charge-" + pal; flightOrb(p, pal, size);
      const at = m.ahead(22); ring(at.x,at.y,pal,3,24,.25,2,24);
      W0([1,2,4][lv],.12);
    } }], sfx: [{ t: -.02, id: "gojoRelease" }]
  });
  ie("gjH1", holdDef(0));
  ie("gjH2", holdDef(1));
  ie("gjH3", holdDef(2));

  /* ---------- 7 skills ---------- */
  const aimPrep = n0(210, 100);

  Yt("gojo1", "gojo", 1, "Xanh · Thuận Chuyển", 14, 4.5, "Tạo một điểm kỳ dị xanh tại vùng ngắm: hút mọi kẻ địch vào tâm, rồi sụp đổ thành vụ nổ nén.", {
    track: [[-.2, GP({ crouch: 4, lean: -2, fx: 6, fy: -22, bx: -2, by: -16 })], [-.04, GP({ crouch: 5, lean: -4, fx: 12, fy: -35, bx: -3, by: -18, toeB: !0 })],
      [0, GP({ x: 1, crouch: 4, lean: 3, fx: 25, fy: -34, bx: -4, by: -18, ffx: 11 }), "snap"], [.4, GP({ lean: 3, fx: 23, fy: -32, bx: -4, by: -18 })], [.62, GP({})]],
    lead: .2, end: .62, cancel: .44, prep: aimPrep,
    on: [{ t: 0, fn: (a, m) => {
      const e = m.o.data, z = 26, pw = m.power;
      // One primary sphere: cast from the hand, arrive, compress, dissipate.
      const castWorld=Y.world, start=m.ahead(18);
      const core=orb(start.x,start.y,z,"blue",1.51,()=>16,{singularity:true,seed:Math.random()*100000|0});
      core.step=()=>{const u=ease(core.age/.24);core.x=start.x+(e.x-start.x)*u;core.y=start.y+(e.y-start.y)*u;};
      Rn(.24,()=>{
        if(!castWorld || Y.world!==castWorld || a.dead || a.gone)return;
        ring(e.x,e.y,"blue",90,8,1.0,2);
        G0(a, { x:e.x,y:e.y,rx:120,ry:52,dur:1.05,tick:.15,first:.12,el:"gojo",pull:210,hit:{dmg:.18*pw,push:0,stun:.3,stop:0,shake:.3,fx:null,pull:120} });
        Rn(1.05,()=>{
          if(Y.world!==castWorld || a.dead || a.gone)return;
          ze(a,{x:e.x,y:e.y,z,fx:"explosions/implosion",rate:1.5,opts:PAL.blue,el:"gojo",hits:[{t:0,rx:84,hit:{dmg:2.6*pw,lift:210,push:70,stun:.65,heavy:!0,fx:null},shake:6,flash:.3,sfx:"gojoBlueEnd"}]});
          addFx({kind:"burst",x:e.x,y:e.y,z,pal:"blue",life:.48,r0:5,r1:80,seed:Math.random()*100000|0});
          ring(e.x,e.y,"blue",6,80,.48,3); streak(e.x,e.y,z,"blue",.32,{n:16,in:4,speed:95});
          near(a) && (a3(2),$U(.8));
        });
      });
      say("ao");
    } }], sfx: [{ t: 0, id: "gojoBlue" }]
  }, { range: 210, tag: "Hút · Điểm xa", show: { fx: "shadow/void-orb", opts: PAL.blue } });

  Yt("gojo2", "gojo", 2, "Đỏ · Phản Chuyển", 18, 5, "Bắn quả cầu đỏ cực nén. Chạm vào là phát nổ, hất văng mọi thứ ra xa.", {
    track: [[-.2, GP({ crouch: 5, lean: -3, fx: 4, fy: -24, bx: -4, by: -18 })], [-.05, GP({ crouch: 5, lean: -6, fx: 14, fy: -30, bx: -5, by: -19, toeB: !0 })],
      [0, GP({ x: 2, crouch: 4, lean: 6, fx: 27, fy: -27, bx: -5, by: -19, ffx: 13, fbx: -10, ghost: 1 }), "snap"], [.3, GP({ lean: 5, fx: 25, fy: -27, bx: -5, by: -19 })], [.54, GP({})]],
    lead: .2, end: .54, cancel: .34,
    on: [{ t: -.1, fn: (a, m) => { const p = m.ahead(26); m.gjRedCharge = orb(p.x, p.y, 27, "red", .22, k => 2 + 8 * ease(k / .9), { spin: 14, fade: .6 }); say("aka"); } },
      { t: 0, fn: (a, m) => {
        const pr = Y0(a, {
          ...d2(a, m), ...Us(m, 330), life: .8, r: 11, el: "gojo", fx: null,
          hit: { dmg: 2.2 * m.power, push: 220, lift: 90, stun: .45, heavy: !0, shake: 4 },
          burst: { fx: "explosions/plasma-explosion", rate: 1.35, rx: 74, onFloor: !0, opts: PAL.red, hit: { dmg: 2.7 * m.power, push: 440, spread: 300, gjRepel: 2, lift: 200, stun: .7, heavy: !0, fx: null }, shake: 8, flash: .3, sfx: "gojoRedEnd" }
        });
        if (m.gjRedCharge) m.gjRedCharge.life = 0;
        pr.gjType="red-skill"; flightOrb(pr, "red", 10);
        const q = m.ahead(26); ring(q.x, q.y, "red", 4, 40, .3, 3, 26); streak(q.x, q.y, 26, "red", .25, { n: 14, speed: 100 });
        W0(2.5, .14); a3(1);
      } }],
    sfx: [{ t: -.05, id: "gojoRed" }]
  }, { range: 230, tag: "Đẩy · Tầm xa", show: { fx: "projectiles/plasma-shot", opts: PAL.red } });

  Yt("gojo3", "gojo", 3, "Thuấn Bộ", 12, 3.2, "Biến mất rồi hiện ra sau lưng kẻ địch gần nhất, tung cước xoay hất tung. Không có địch thì bước một đoạn.", {
    track: [[-.1, GP({ crouch: 5, lean: 4, fx: 6, fy: -18, bx: -3, by: -17 })], [0, GP({ x: 3, crouch: 3, lean: -8, fx: -4, fy: -22, bx: 7, by: -28, ffx: 18, ffy: -20, fbx: -3, toeB: !0, ghost: 1 }), "snap"],
      [.18, GP({ x: 3, crouch: 3, lean: -8, fx: -4, fy: -22, bx: 7, by: -28, ffx: 17, ffy: -19 })], [.42, GP({ x: 3 })]],
    lead: .08, end: .42, cancel: .28,
    prep: (a, m) => {
      const tg = l2(a, 240);
      let x, y, th;
      if (tg) { const s = Math.sign(tg.x - a.x) || a.face; x = tg.x - s * 28; y = tg.y + 1; th = Math.atan2(tg.y - y, tg.x - x); }
      else { let ex = a.intent?.mx ?? 0, ey = (a.intent?.my ?? 0) * .7; const l = Math.hypot(ex, ey); if (m?.manual || l < .3) { ex = Math.cos(En(a)); ey = Math.sin(En(a)); } else { ex /= l; ey /= l; } let d = 150; while (d > 20 && Y.world?.blocked(a.x + ex * d, a.y + ey * d)) d -= 16; x = a.x + ex * d; y = a.y + ey * d; th = Math.atan2(ey, ex); }
      let g = 0; while (g++ < 8 && Y.world?.blocked(x, y)) { x = (x + a.x) / 2; y = (y + a.y) / 2; }
      return { x: Math.round(x), y: Math.round(y), fx: Math.round(a.x), fy: Math.round(a.y), th, tg: !!tg };
    },
    on: [{ t: -.06, fn: (a, m) => {
      const e = m.o.data;
      ring(e.fx, e.fy, "blue", 4, 46, .35, 3); streak(e.fx, e.fy, 20, "blue", .3, { n: 18, speed: 150 });
      a.x = e.x; a.y = e.y; a.z = 0; a.vx = a.vy = 0; a.nb = null; a.invuln = Math.max(a.invuln, .5);
      e0(a, e.th);
      ring(e.x, e.y, "blue", 3, 40, .3, 3); gh(a, 7);
      addFx({kind:"burst",x:e.x,y:e.y,z:20,pal:"blue",life:.24,r0:4,r1:35,seed:Math.random()*100000|0});
      near(a) && (a3(1), W0(2, .12));
      say("blink");
    } }],
    hits: [{ t: .02, kind: "circle", rx: 62, ry: 34, ox: 18, dmg: 2.4, push: 140, lift: 190, stun: .6, stop: .1, shake: 4.5, heavy: !0, fx: "impacts/crit-hit" }],
    sfx: [{ t: -.06, id: "gojoBlink" }, { t: .02, id: "gojoPunch" }]
  }, { range: 150, tag: "Lao tới", show: { fx: "impacts/hit-spark", opts: PAL.blue } });

  Yt("gojo4", "gojo", 4, "Vô Hạ Hạn", 24, 15, "Khoảng cách giữa bạn và đòn đánh trở nên vô hạn trong 5 giây: không gì chạm được, kẻ địch lại gần bị đẩy bật ra.", {
    track: [[-.15, GP({ crouch: 3, lean: -2, fx: 8, fy: -22, bx: -4, by: -18 })], [0, GP({ x: 0, crouch: 3, lean: -4, fx: 22, fy: -26, bx: -7, by: -24, ffx: 9, fbx: -8 }), "snap"],
      [.3, GP({ lean: -4, fx: 21, fy: -26, bx: -7, by: -24 })], [.55, GP({})]],
    lead: .15, end: .55, cancel: .3, armorT: .6,
    on: [{ t: 0, fn: (a, m) => {
      a.addStatus("ward", { dur: 5 }); a.infT = 5; a.invuln = Math.max(a.invuln, .5);
      addFx({ kind: "dome", follow: a, life: 5, pal: "blue" });
      ring(a.x, a.y, "blue", 6, 64, .6, 4); ring(a.x, a.y, "blue", 2, 44, .45, 3);
      G0(a, { x: a.x, y: a.y, rx: 66, ry: 36, dur: 5, tick: .45, first: .25, follow: a, el: "gojo", hit: { dmg: .12, push: 150, stun: .35, stop: 0, shake: 0, fx: null } });
      say("mugen");
    } }], sfx: [{ t: 0, id: "gojoMugen" }]
  }, { range: 70, tag: "Phòng thủ", show: { fx: "holy/divine-shield", opts: PAL.blue } });

  Yt("gojo5", "gojo", 5, "Phản Chuyển Hồi Phục", 26, 16, "Dùng năng lượng nguyền rủa phản chuyển để chữa lành: hồi 45% sinh lực cho bạn và đồng đội gần, gột sạch trạng thái xấu.", {
    track: [[-.12, GP({ crouch: 3, lean: -2, fx: 4, fy: -22, bx: -2, by: -18 })], [0, GP({ crouch: 4, lean: -3, fx: 7, fy: -29, bx: 8, by: -26, armsFront: !0 }), "snap"],
      [.9, GP({ crouch: 4, lean: -3, fx: 7, fy: -29, bx: 8, by: -26, armsFront: !0 })], [1.05, GP({})]],
    lead: .12, end: 1.05, cancel: .95, armorT: 1.1,
    on: [{ t: 0, fn: (a, m) => {
      say("rct");
      Rt("holy/heal-aoe", { x: a.x, y: a.y, rate: 1, prio: 2 });
      addFx({kind:"heal",follow:a,life:1.2,seed:Math.random()*100000|0});
      for (let i = 0; i < 6; i++) Rn(i * .16, () => {
        if (a.dead || a.gone) return;
        for (const r of Y.players) if ((r.local || r === a) && r.alive && Dr(a, r) && Math.hypot(r.x - a.x, (r.y - a.y) * 1.6) < 150) t0(r, r.maxHp * .075);
        orb(a.x + (Math.random() - .5) * 20, a.y, 10 + Math.random() * 28, Math.random() > .5 ? "blue" : "red", .35, k => 4 * (1 - k) + 1, { spin: 5 });
      });
      M3(a, a.x, a.y, 150, 0);
      ring(a.x, a.y, "red", 4, 60, .8, 3); ring(a.x, a.y, "blue", 8, 72, .8, 2);
    } }], sfx: [{ t: 0, id: "gojoHeal" }]
  }, { range: 90, tag: "Hồi phục", show: { fx: "holy/heal", opts: {} } });

  Yt("gojo6", "gojo", 6, "Hư Thức · Tím", 40, 12, "Va chạm Xanh và Đỏ: tạo khối Tím xóa sổ mọi thứ trên đường bay, xuyên qua tất cả kẻ địch.", {
    track: [[-.34, GP({ crouch: 4, lean: -3, fx: 4, fy: -22, bx: -3, by: -18 })], [-.2, GP({ crouch: 5, lean: -5, fx: 12, fy: -36, bx: 14, by: -22, armsFront: !0, toeB: !0 })],
      [0, GP({ crouch: 5, lean: -3, fx: 22, fy: -31, bx: 18, by: -26, armsFront: !0, ghost: 1 }), "snap"],
      [.3, GP({ x: 0, crouch: 5, lean: -4, fx: 24, fy: -30, bx: 20, by: -27, armsFront: !0 })], [.34, GP({ x: -4, crouch: 6, lean: 5, fx: 29, fy: -29, bx: 26, by: -27, armsFront: !0, ghost: 1 }), "snap"],
      [1.2, GP({ x: -4, crouch: 6, lean: 5, fx: 29, fy: -29, bx: 26, by: -27, armsFront: !0 })], [1.5, GP({})]],
    lead: .34, end: 1.5, cancel: 1.28, armorT: 1.4, rootK: .5,
    on: [
      { t: -.3, fn: (a, m) => {
        a.eyesT = 3; say("murasaki", { ms: 3200 });
        const px = a.x + m.ux * 28, py = a.y + m.uy * 28, z = 30;
        const bo = orb(a.x - m.ux * 18, a.y - m.uy * 18, z, "blue", .56, () => 11, { spin: 11 });
        const ro = orb(a.x + m.ux * 54, a.y + m.uy * 54, z, "red", .56, () => 11, { spin: -11 });
        m.gjPair = [bo, ro];
        bo.mv = [bo.x, bo.y, px, py]; ro.mv = [ro.x, ro.y, px, py];
        const upd = (o) => () => { const k = ease(clamp(o.age / .5)); o.x = o.mv[0] + (o.mv[2] - o.mv[0]) * k; o.y = o.mv[1] + (o.mv[3] - o.mv[1]) * k; };
        bo.step = upd(bo); ro.step = upd(ro);
      } },
      { t: .22, fn: (a, m) => {
        const px = a.x + m.ux * 28, py = a.y + m.uy * 28;
        for (const o of m.gjPair ?? []) { const i = fxs.indexOf(o); if (i >= 0) fxs.splice(i, 1); }
        m.gjMerge = orb(px, py, 30, "purple", .35, k => 6 + 12 * ease(k / .5), { spin: 16, fade: .85 });
        S.inv = Math.max(S.inv, .07); R2(.1); near(a) && (W0(5, .3), a3(3));
        ring(px, py, "purple", 4, 70, .45, 4, 30); ring(px, py, "blue", 4, 50, .35, 3, 30);
        a.local && o3(SX(px), SY(py, 30), 2, "#b46cff");
        tc(.3, .55);
      } },
      { t: .34, fn: (a, m) => {
        const px = a.x + m.ux * 16, py = a.y + m.uy * 16;
        if (m.gjMerge) { const i = fxs.indexOf(m.gjMerge); if (i >= 0) fxs.splice(i,1); }
        const p = Y0(a, { ...d2(a,m), ...Us(m, 340), life: 1.55, r: 43, el: "gojo", fx: null, pierce: 99,
          hit: { dmg: 6.8 * m.power, push: 210, lift: 80, stun: .7, stop: .04, shake: 4, heavy: !0, fx: null },
          burst: { fx: "explosions/plasma-explosion", opts: PAL.purple, rate: 1.15, rx: 120, ry: 65, onFloor: !0,
            hit: { dmg: 4.2 * m.power, push: 320, spread: 180, lift: 180, stun: .9, stop: .12, heavy: !0, fx: "impacts/crit-hit" },
            shake: 10, flash: .25, sfx: "gojoRedEnd" }
        });
        p.gjType = "purple-skill";
        const v=orb(p.x,p.y,p.z,"purple",.22,()=>43,{spin:14});v.kind="purple";v.projectile=p;
        v.step=()=>{if(p.dead||!Y.projs.includes(p)){v.life=0;return}v.age=0;v.x=p.x;v.y=p.y;v.z=p.z};
        const trail=addFx({kind:"purpleTrail",life:4.0,chunks:[],shot:p,last:0});
        trail.step=()=>{
          if(!p.dead && Y.projs.includes(p)){
            trail.age=0;
            if(S.t>=trail.last){trail.last=S.t+.055;const len=Math.hypot(p.vx,p.vy)||1;trail.chunks.push({x:p.x,y:p.y,ux:p.vx/len,uy:p.vy/len,born:S.t,seed:Math.random()*9999|0});}
          }
          trail.chunks=trail.chunks.filter(v=>S.t-v.born<3.8);
        };
        p.onStep=shot=>{
          if(near(shot,400)) W0(2.2,.14);
          // Remote move replicas don't own collisions; predict visuals only.
          if(!a.local && !shot.gjTouched){
            for(const e of Y.ents){
              if(!e.alive || !R0(a,e))continue;
              const dx=e.x-shot.x,dy=(e.y-shot.y)*1.8,r=shot.r+(e.r??7);
              if(dx*dx+dy*dy<=r*r && (e.z??0)<=shot.z+14 && (e.z??0)+(e.h??30)>=shot.z-12){projectileHit(shot,e,{});break;}
            }
          }
        };
        a.local && o3(SX(px), SY(py,30), 2, "#b46cff");
        W0(5,.22,m.ux,0); $U(.9);
      } },
    ],
    sfx: [{ t: -.3, id: "gojoPurple" }, { t: .34, id: "gojoBeam" }]
  }, { range: 430, tag: "Xuyên · Tuyệt đối", show: { fx: "arcane/arcane-orb", opts: PAL.purple } });

  Yt("gojoU", "gojo", 7, "Lĩnh Vực · Vô Lượng Không Xứ", 0, 0, "Tuyệt kỹ. Mở Lĩnh Vực: mọi kẻ địch trong tầm mắt chìm trong vũ trụ thông tin vô hạn, bị khóa trong 8 giây. Sát thương của Gojo tăng gấp 3 và mọi đòn gây sát thương đều bạo kích; kết thúc bằng một đòn bạo kích.", {
    track: [[-.5, GP({ crouch: 4, lean: -2, fx: 5, fy: -21, bx: -2, by: -18 })], [-.2, GP({ crouch: 5, lean: -4, fx: 16, fy: -32, bx: 14, by: -31, armsFront: !0 })],
      [0, GP({ crouch: 5, lean: -2, fx: 22, fy: -33, bx: 19, by: -32, armsFront: !0, ghost: 1 }), "snap"], [1.1, GP({ crouch: 5, lean: -2, fx: 22, fy: -33, bx: 19, by: -32, armsFront: !0 })], [1.4, GP({})]],
    lead: .5, end: 1.4, cancel: 1.3, armorT: 1.8,
    on: [{ t: -.5, fn: (a, m) => {
      a.eyesT = 7; a.invuln = Math.max(a.invuln, 3.2);
      say("domain", { ms: 4200 });
      near(a) && (R2(.18), W0(4, .5), a3(3));
      tc(.35, 1.3);
      const castWorld = Y.world;
      Rn(.5, () => {
        if (!castWorld || Y.world !== castWorld || a.dead || a.gone) return;
        const target = l2(a, 620);
        S.exit = null;
        S.dom = { x: a.x, y: a.y, ex: target?.x ?? a.x + a.face * 100, ey: target?.y ?? a.y, t: 0, dur: 8.2, seed: Math.random()*100000|0, world: Y.world, owner: a, power: m.power, finished: false }; S.stars = null;
        a.local && o3(SX(a.x), SY(a.y, 20), 3, "#9fb4ff");
        $U(.8);
        domainFreeze(S.dom);
        ot("sfx", "gojoDomain", a);
      });
    } }], sfx: []
  }, { range: 300, tag: "Lĩnh vực", show: { fx: "shadow/void-orb", opts: PAL.purple } });

  // The base game computes targeting shapes before this late-loaded module is inserted.
  // Explicit definitions keep hold-to-aim working for every Gojo skill.
  fe.gojo1.shape = { kind: "point", range: 210, r: 120 };
  fe.gojo2.shape = { kind: "line", len: 230, w: 74 };
  fe.gojo3.shape = { kind: "self", r: 240 };
  fe.gojo4.shape = { kind: "self", r: 66 };
  fe.gojo5.shape = { kind: "self", r: 150, kind2: "ally" };
  fe.gojo6.shape = { kind: "line", len: 430, w: 72 };
  fe.gojoU.shape = { kind: "self", r: 620 };

  function projectileEnd(p) {
    if(p.gjType!=="red-skill" && p.gjType!=="charge-red")return;
    addFx({kind:"burst",x:p.x,y:p.y,z:p.z,pal:"red",life:.42,r0:4,r1:p.gjType==="red-skill"?65:45,seed:Math.random()*100000|0});
  }
  function projectileHit(p,target,hit) {
    if(p.gjType!=="purple-skill" || !hit) return;
    if(!p.gjTouched){p.gjTouched=true;p.life=p.t+.55;}
    if(near(p,400)){
      if(lt.flashScale>0) S.inv=Math.max(S.inv,.065);
      R2(.045);W0(5,.16);a3(2);
    }
    ring(target.x,target.y,"purple",4,55,.3,2,20);
  }
  function damageMultiplier(a) {
    const d=S.dom;
    return d && d.world===Y.world && d.owner===a && !a.dead && a.el==="gojo" && d.t<d.dur ? 3 : 1;
  }
  function forceDomainCrit(a,hit) { return (hit.dmg??1)>0 && damageMultiplier(a)===3; }
  function domainFreeze(d) {
    const a=d.owner;
    // Host controls foe AI. The initiating client also sends a zero-damage status
    // packet, so late/rejoining peers and versus targets receive the same lock.
    const targets=a.local ? Ay(a) : Y.isHost ? Y.ents.filter(e=>e.team==='foe') : [];
    for(const e of targets){
      if(!e.alive || !R0(a,e))continue;
      const dx=(e.x-d.x)/620,dy=(e.y-d.y)/330;
      if(dx*dx+dy*dy>1 || (e.z??0)>200) continue;
      if(e.auth){e.addStatus("gjVoid",{dur:e.boss?.8:.4});e.vx=e.vy=0;}
      else if(a.local && e.team==='foe' && (!(e.gjLockUntil > S.t) || e.gjLockDomain !== d)){
        e.gjLockDomain=d; e.gjLockUntil=S.t+.25;
        ot("netHit",e,{dmg:0,dir:a.face,kx:0,ky:0,lift:0,stun:0,soft:true,el:"gojo",status:{id:"gjVoid",dur:e.boss?1.2:.6},by:a});
      }
    }
  }

  // Red attacks move the practice dummy; friction stops it where it lands.
  function dummyHit(d, hit) {
    if (!hit.gjRepel || hit.by?.el !== "gojo") return;
    const x = hit.kx || hit.dir || 1, y = hit.ky || 0, len = Math.hypot(x,y) || 1;
    const speed = hit.gjRepel >= 2 ? 350 : 160;
    d.gjSlide = true; d.gjVx = x / len * speed; d.gjVy = y / len * speed * .6;
  }
  function dummyStep(d, dt) {
    if (!d.gjSlide || dt <= 0) return;
    d.x += d.gjVx * dt; d.y += d.gjVy * dt;
    const drag = Math.exp(-5.2*dt); d.gjVx *= drag; d.gjVy *= drag;
    Y.world?.collide(d);
    if(Math.hypot(d.gjVx,d.gjVy)<.20){d.gjVx=0;d.gjVy=0;d.gjSlide=false;}
  }

  /* ---------- hero integration ---------- */
  const hold = {
    input(h, pressed, dt) {
      if (pressed) { h.gjHold = 0; h.gjLv = -1; h.gjArmed = !0; return !0; }
      const down = pt.down.attack;
      if (down && h.gjArmed && !h.dead) {
        h.gjHold += dt;
        if (h.gjHold > .38 && h.canAct && h.st !== "dash") {
          if (!h.gjCharging) {
            h.gjCharging = !0; h.cancelMove?.(!1);
            h.gjOrb = orb(h.x, h.y, 24, "blue", .22, () => 3, { spin: 14, owner: h, charge: true });
            ot("sfx", "gojoCharge", h); say("hold", { ms: 1500 });
          }
          const lv = h.gjHold >= 2.1 ? 2 : h.gjHold >= .95 ? 1 : 0;
          if (h.gjLv !== lv) { h.gjLv = lv; if (h.local) ot("word", ["Xanh", "Đỏ · Đẩy", "Tím · Bạo kích"][lv], h, "gojo"); }
          h.intent.mx = h.intent.my = 0;
          if (!h.gjOrb || !fxs.includes(h.gjOrb)) h.gjOrb = orb(h.x, h.y, 24, "blue", .22, () => 3, { spin: 14, owner: h, charge: true });
          const o = h.gjOrb; o.age = 0; o.life = .22; o.x = h.x + h.face * 17; o.y = h.y; o.z = 24;
          o.r = () => 3 + Math.min(1.4, h.gjHold - .3) * 6 + Math.sin(S.t * 30) * .8; o.pal = lv >= 2 ? "purple" : lv ? "red" : "blue";
          if (Math.floor(h.gjHold * 14) !== Math.floor((h.gjHold - dt) * 14)) {
            ring(h.x, h.y, o.pal, 40, 6, .22, 2, 8);
            if (lv && Math.floor(h.gjHold * 7) !== Math.floor((h.gjHold - dt) * 7)) { ot("sfx", "gojoCharge", h); W0(.8 + lv, .1); }
          }
        }
        return !1;
      }
      if (h.gjCharging) {
        h.gjCharging = !1; if (h.gjOrb) { h.gjOrb.life = 0; h.gjOrb.age = 1; h.gjOrb = null; }
        if (h.gjHold > .38) { const lv = h.gjHold >= 2.1 ? 2 : h.gjHold >= .95 ? 1 : 0; const aim = h.strikeAim ? h.strikeAim(220) : {}; Yi(h, ["gjH1", "gjH2", "gjH3"][lv], { aim: aim.tgt, th: aim.th }); h.chainI = -1; }
      }
      h.gjArmed = !1; h.gjHold = 0;
      return !1;
    },
    chargePose(h) {
      const sh = Math.floor(h.gjHold * 24) % 2;
      return GP({ crouch: 5 + (h.gjLv ?? 0), lean: -4 - (h.gjLv ?? 0), fx: 17 + sh, fy: -27, bx: 3, by: -21, ffx: 9, fbx: -8, ghost: h.gjLv >= 2 ? 1 : 0 });
    },
    hover(h, dt) {
      if (h.z <= 0) { h.hov = 0; return; }
      if (h.z > 3 && h.vz < 40 && pt.down.jump && (h.hov ?? 0) < 1.15 && !h.plunge && h.st === "jump") {
        h.vz = Math.max(h.vz, -34); h.hov = (h.hov ?? 0) + dt;
        if (Math.floor(h.hov * 9) !== Math.floor((h.hov - dt) * 9)) ring(h.x, h.y, "blue", 4, 22, .3, 2, 0);
      }
    },
    dashFx(h) {
      ring(h.x, h.y, "blue", 3, 30, .28, 2);
      streak(h.x, h.y, 20, "blue", .25, { n: 12, speed: 110 });
      Rn(.2, () => { if (!h.gone) ring(h.x, h.y, "blue", 3, 20, .2, 2); });
      ot("sfx", "gojoBlink", h);
    },
    mugen(h, t) {
      if (!h.local || Y.t < (h.mugenAt ?? 0) || !(t.dmg > 0)) return !1;
      h.mugenAt = Y.t + 8; h.gjBlockT = S.t;
      ring(h.x, h.y, "blue", 6, 52, .45, 4); ring(h.x, h.y, "blue", 3, 36, .3, 3);
      streak(h.x, h.y, 20, "blue", .25, { n: 14, speed: 90 });
      Rt("impacts/shield-block", { x: h.x, y: h.y + 1, z: 22, palette: HEX.blue, prio: 2, flip: (t.dir ?? 1) > 0 });
      ot("sfx", "gojoBlock", h); W0(2, .12);
      if (t.by && !t.by.dead) c2(h, t.by, { dmg: 0, push: 170, stun: .5, stop: .06, shake: 2, fx: null }, t.dir ?? h.face);
      ot("word", "Vô hạn", h, "gojo");
      return !0;
    },
  };

  /* ---------- skill icons (generated pixel art) ---------- */
  let iconUrl = null;
  function icons() {
    if (iconUrl) return iconUrl;
    const c = document.createElement("canvas"); c.width = 168; c.height = 24;
    const g = c.getContext("2d"), im = g.createImageData(168, 24), d = new Uint32Array(im.data.buffer);
    const put = (ox, x, y, col) => { if (x >= 0 && y >= 0 && x < 24 && y < 24) d[y * 168 + ox + x] = 0xFF000000 | (col[2] << 16) | (col[1] << 8) | col[0]; };
    const sphere = (ox, cx, cy, r, P) => { for (let y = 0; y < 24; y++) for (let x = 0; x < 24; x++) { const dd = Math.hypot(x - cx, y - cy) / r; if (dd > 1) continue; const l = (1 - dd) * .85 - ((x - cx) + (y - cy)) / (r * 7) + dith(x, y) * .25; put(ox, x, y, P[Math.floor(clamp(l * 6.99 + 1, 0, 6.99))]); } };
    for (let i = 0; i < 7; i++) {
      const ox = i * 24;
      for (let y = 0; y < 24; y++) for (let x = 0; x < 24; x++) { const dd = Math.hypot(x - 11.5, y - 11.5); put(ox, x, y, dd > 11.6 ? [0, 0, 0] : dd > 10 ? RGB.blue[2] : [10, 12 + (y >> 1), 30 + y]); }
      if (i === 0) { sphere(ox, 12, 12, 7, RGB.blue); for (let a = 0; a < 6.3; a += .15) put(ox, Math.round(12 + Math.cos(a) * 9.5), Math.round(12 + Math.sin(a) * 4), RGB.blue[5]); }
      if (i === 1) { sphere(ox, 12, 12, 7, RGB.red); for (let k = 0; k < 8; k++) { const a = k * .785; put(ox, Math.round(12 + Math.cos(a) * 10), Math.round(12 + Math.sin(a) * 10), RGB.red[5]); } }
      if (i === 2) { for (let k = 0; k < 20; k++) { put(ox, 3 + k, 19 - k, [255, 255, 255]); put(ox, 4 + k, 19 - k, RGB.blue[4]); put(ox, 2 + k, 19 - k, RGB.blue[3]); } for (let k = 0; k < 5; k++) { put(ox, 16 + k, 5 + k, RGB.blue[5]); put(ox, 16 + k, 13 - k, RGB.blue[5]); } }
      if (i === 3) { for (let r = 3; r <= 10; r += 3) for (let a = 0; a < 6.3; a += .08) put(ox, Math.round(12 + Math.cos(a) * r), Math.round(12 + Math.sin(a) * r), RGB.blue[r > 8 ? 3 : r > 5 ? 4 : 6]); }
      if (i === 4) { for (let k = -7; k <= 7; k++) for (let w = -2; w <= 2; w++) { put(ox, 12 + k, 12 + w, [140, 255, 190]); put(ox, 12 + w, 12 + k, [140, 255, 190]); } put(ox, 12, 12, [255, 255, 255]); }
      if (i === 5) { sphere(ox, 12, 12, 8, RGB.purple); for (let y = 0; y < 24; y++) for (let x = 0; x < 24; x++) { if (Math.hypot(x - 12, y - 12) < 8 && (x + y) % 5 === 0) put(ox, x, y, x < 12 ? RGB.blue[5] : RGB.red[4]); } }
      if (i === 6) { for (let y = 0; y < 24; y++) for (let x = 0; x < 24; x++) { if (Math.hypot(x - 11.5, y - 11.5) < 10 && hash(x, y) > .9) put(ox, x, y, [255, 255, 255]); } for (let x = 4; x < 20; x++) { const h = Math.round(Math.sin((x - 4) / 15 * Math.PI) * 5); put(ox, x, 12 - h, RGB.void[7]); put(ox, x, 12 + h, RGB.void[7]); } sphere(ox, 12, 12, 3, RGB.purple); put(ox, 12, 12, [255, 255, 255]); }
    }
    g.putImageData(im, 0, 0); iconUrl = c.toDataURL();
    return iconUrl;
  }

  /* ---------- unlock via code ---------- */
  function unlock(silent) {
    const s = Y.save; if (!s) return !1;
    const first = !s.gojo;
    s.gojo = 1; if (!na.includes("gojo")) na.push("gojo");
    if (!s.load) s.load = {};
    if (!s.load.gojo) s.load.gojo = [];
    for (const id of ss.gojo) if (id) s.skills[id] = 1;
    if (first || !s.load.gojo.length) s.load.gojo = ["gojo1", "gojo2", "gojo6", "gojo3"];
    s.el = "gojo"; Pn(); q0();
    const me = Y.me;
    if (me && me.setElement) { me.setElement("gojo"); me.chainI = -1; }
    if (!silent) {
      say("honored", { ms: 4200 });
      ot("toast", "Đã mở khóa Gojo Satoru!", "good");
      ot("banner", "Gojo Satoru", "Lục Nhãn · Vô Hạ Hạn", "ult", "gojo");
      if (me) { ring(me.x, me.y, "blue", 6, 120, .9, 4); streak(me.x, me.y, 22, "blue", .6, { n: 36, speed: 260 }); W0(4, .4); as("#bff0ff", .6, 5); }
    }
    return !0;
  }
  function redeem(raw) {
    const c = String(raw || "").trim().toLowerCase().replace(/\s+/g, "");
    if (c === "gojo" || c === "gojosatoru" || c === "satorugojo" || c === "六眼") return unlock();
    ot("toast", "Mã không đúng", "warn"); return !1;
  }
  function codeRow() {
    const wrap = document.createElement("div"); wrap.className = "gj-code";
    const lab = document.createElement("div"); lab.className = "t9 c-dim"; lab.textContent = "Nhập mã nhân vật";
    const row = document.createElement("div"); row.className = "gj-row";
    const inp = document.createElement("input"); inp.type = "text"; inp.placeholder = "Nhập mã…"; inp.autocomplete = "off"; inp.autocapitalize = "off"; inp.spellcheck = !1; inp.maxLength = 24; inp.setAttribute("aria-label", "Nhập mã");
    const btn = ce("Nhận", () => { if (redeem(inp.value)) inp.value = ""; }, "sm");
    inp._enter = () => btn.click(); // works with the game's capture-phase keyboard handler
    inp.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); btn.click(); } e.stopPropagation(); });
    row.append(inp, btn); wrap.append(lab, row);
    if (Y.save?.gojo) { const ok = document.createElement("div"); ok.className = "t7 c-el"; ok.textContent = "Gojo Satoru đã mở khóa. Đổi hệ bằng nút đổi hành."; wrap.append(ok); }
    return wrap;
  }

  _t("frame", dt => {
    // Always age and collect effects, even when they are off-screen or a draw is skipped.
    dt = Number.isFinite(dt) ? Math.max(0, Math.min(dt, .1)) : 0;
    S.dt = dt; S.t += dt;
    for (const p of Y.players) {
      if (p.eyesT > 0) p.eyesT -= dt;
      if (p.gjCharging && (p.dead || p.gone || p.held || p.el !== "gojo" || ["hurt", "air", "down", "getup", "dash"].includes(p.st) || !pt.enabled || Y.cine)) {
        p.gjCharging = false; p.gjArmed = false; p.gjHold = 0;
        if (p.gjOrb) p.gjOrb.life = 0;
        p.gjOrb = null;
      }
    }
    if (dt > 0 && Y.world) for (const owner of Y.players) {
      if (!owner || owner.dead || owner.gone || owner.el !== "gojo" || !owner.statuses?.has("ward")) continue;
      const targets = owner.local ? I_(owner) : [...(Y.isHost ? Y.ents.filter(e => e.team === "foe") : []), ...(Y.versus ? I_(owner) : [])];
      for (const target of targets) {
        if (!target.auth || target.dead || target.gone || target === owner || target.team === "foe" && !Y.isHost || target.hero && (!Y.versus || !target.local)) continue;
        if ((target.z ?? 0) > 55 || Math.abs((owner.z ?? 0) - (target.z ?? 0)) > 55) continue;
        const dx = target.x - owner.x, dy = target.y - owner.y, ratio = .54;
        const dist = Math.hypot(dx, dy / ratio), radius = 29 + (target.r ?? 7);
        if (dist >= radius) continue;
        const nx = dist > .01 ? dx / dist : (owner.face || 1), ny = dist > .01 ? dy / dist : 0;
        target.x += nx * (radius - dist); target.y += ny * (radius - dist);
        Y.world.collide(target);
        const radial = (target.vx ?? 0) * nx + (target.vy ?? 0) * ny / ratio;
        const speed = target.boss ? 25 : 95;
        if (radial < speed) { target.vx += nx * (speed - radial); target.vy += ny * (speed - radial); }
        if (!(target.gjBarrierFxT > Y.t)) {
          target.gjBarrierFxT = Y.t + .35;
          Rt("impacts/shield-block", { x: owner.x + nx * 29, y: owner.y + ny * 29, z: 20, palette: HEX.blue, prio: 1 });
        }
      }
    }
    if (S.inv > 0) S.inv -= dt;
    for (let i = fxs.length - 1; i >= 0; i--) {
      const o = fxs[i]; o.age += dt;
      if (!Number.isFinite(o.age) || !Number.isFinite(o.life) || o.age >= o.life || o.world !== Y.world || (o.charge && (!o.owner || o.owner.dead || o.owner.gone || o.owner.el !== "gojo"))) { fxs.splice(i, 1); continue; }
      if (o.step) o.step(o, dt);
    }
    if(S.exit){if(!(Y.paused && !Y.online))S.exit.t+=dt;if(S.exit.t>=.85 || S.exit.world!==Y.world)S.exit=null;}
    if (S.dom) {
      const d = S.dom;
      if (!Y.world || d.world !== Y.world || Y.mode === "none" || !d.owner || d.owner.dead || d.owner.gone || d.owner.el !== "gojo") { S.dom = null; S.stars = null; }
      else {
        if (!(Y.paused && !Y.online)) d.t += dt;
        if (d.t < d.dur) domainFreeze(d);
        if (!d.finished && d.t >= 7.35) {
          d.finished = true;
          const a = d.owner;
          for(const e of Y.ents) if(e.auth && e.statuses?.has("gjVoid")) e.clearStatus("gjVoid");
          ze(a, { x: d.x, y: d.y, el: "gojo", hits: [{ t: 0, rx: 640, ry: 340, zmax: 220, hit: { dmg: 3.8 * d.power, crit: 1, push: 0, lift: 220, stun: 1.2, stop: .12, heavy: !0, fx: "impacts/crit-hit" }, shake: 9, flash: .25, sfx: "gojoBlueEnd" }] });
          if (a.local) { if(lt.flashScale>0) S.inv=Math.max(S.inv,.07); o3(SX(d.ex), SY(d.ey, 20), 2, "#e6edff"); }
        }
        if (d.t >= d.dur) { S.exit={t:0,world:Y.world}; S.dom = null; S.stars = null; }
      }
    }
  });
  _t("cast", (a, o) => { if (o && o.el === "gojo" && a.local && o.id !== "gojoU") ot("word", o.name.split(" · ")[0], a, "gojo"); });

  return { ground, projectileHit, projectileEnd, damageMultiplier, forceDomainCrit, dummyHit, dummyStep, voidReady: () => !!voidArt.pixels, getShape: id => fe[id]?.shape, sfx: SFX, S, say, post, bg: domainBg, hold, icons, redeem, unlock, codeRow, ring, streak, orb, beam, LINES, fxs, GP, GLOOK, filter: arr => {
    const d = S.dom; if (!d || d.t > 8.0) return;
    const W = lt.W, H = lt.H, x = clamp(SX(d.ex), W*.08, W*.92), y = clamp(SY(d.ey,20), H*.1, H*.9);
    const edge = (Math.hypot(Math.max(x,W-x), Math.max(y,H-y))+10) * ease(d.t/1.65);
    for (let i = arr.length - 1; i >= 0; i--) {
      const o = arr[i].prop || (["fire/campfire", "game/w-petals"].includes(arr[i].fx?.id) ? arr[i].fx : null);
      if (o && Math.hypot(SX(o.x)-x, SY(o.y,0)-y) < edge) arr.splice(i,1);
    }
  } };
})();
